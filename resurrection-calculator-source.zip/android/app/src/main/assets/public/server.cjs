var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_vite = require("vite");
var import_dotenv = __toESM(require("dotenv"), 1);
import_dotenv.default.config();
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = 3e3;
  app.use(import_express.default.json());
  app.use((req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS, HEAD");
    res.setHeader("Access-Control-Allow-Headers", "*");
    next();
  });
  app.get(["/manifest.json", "/manifest.webmanifest"], (req, res) => {
    const manifestPath = import_path.default.join(process.cwd(), "public", "manifest.json");
    res.setHeader("Content-Type", "application/manifest+json; charset=utf-8");
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Cache-Control", "public, max-age=3600");
    res.sendFile(manifestPath);
  });
  app.get("/sw.js", (req, res) => {
    const swPath = import_path.default.join(process.cwd(), "public", "sw.js");
    res.setHeader("Content-Type", "application/javascript; charset=utf-8");
    res.setHeader("Service-Worker-Allowed", "/");
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    res.sendFile(swPath);
  });
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", timestamp: Date.now() });
  });
  app.get(["/download-zip", "/api/download-zip"], (req, res) => {
    const zipPath = import_path.default.join(process.cwd(), "public", "resurrection-calculator-source.zip");
    if (import_fs.default.existsSync(zipPath)) {
      res.setHeader("Content-Type", "application/zip");
      res.setHeader("Content-Disposition", 'attachment; filename="resurrection-calculator-source.zip"');
      res.sendFile(zipPath);
    } else {
      res.status(404).send("ZIP file not found. Please generate it first.");
    }
  });
  app.get("/api/quote", async (req, res) => {
    try {
      const rawSymbol = String(req.query.symbol || "").trim();
      if (!rawSymbol) {
        return res.status(400).json({ error: "Ticker symbol is required (e.g. AAPL, NVDA, TSLA)." });
      }
      const symbol = rawSymbol.toUpperCase();
      const apiKey = process.env.FINNHUB_API_KEY || "dagh4ghr01quf8muaal0dagh4ghr01quf8muaalg";
      const finnhubQuoteUrl = `https://finnhub.io/api/v1/quote?symbol=${encodeURIComponent(symbol)}&token=${apiKey}`;
      const finnhubProfileUrl = `https://finnhub.io/api/v1/stock/profile2?symbol=${encodeURIComponent(symbol)}&token=${apiKey}`;
      const [quoteRes, profileRes] = await Promise.all([
        fetch(finnhubQuoteUrl),
        fetch(finnhubProfileUrl).catch(() => null)
      ]);
      if (!quoteRes.ok) {
        return res.status(quoteRes.status).json({
          error: `Finnhub API responded with status ${quoteRes.status}: ${quoteRes.statusText}`
        });
      }
      const data = await quoteRes.json();
      if (!data || data.c === 0 && data.pc === 0 && data.h === 0) {
        return res.status(404).json({
          error: `No market quote found for "${symbol}". Please check the ticker symbol and try again.`
        });
      }
      let companyName = "";
      if (profileRes && profileRes.ok) {
        try {
          const profileData = await profileRes.json();
          if (profileData && profileData.name) {
            companyName = profileData.name;
          }
        } catch {
        }
      }
      if (!companyName) {
        try {
          const searchUrl = `https://finnhub.io/api/v1/search?q=${encodeURIComponent(symbol)}&token=${apiKey}`;
          const searchRes = await fetch(searchUrl);
          if (searchRes.ok) {
            const searchData = await searchRes.json();
            const match = searchData?.result?.find((r) => r.symbol?.toUpperCase() === symbol);
            if (match?.description) {
              companyName = match.description;
            }
          }
        } catch {
        }
      }
      const KNOWN_NAMES = {
        TSLA: "Tesla, Inc.",
        AAPL: "Apple Inc.",
        NVDA: "NVIDIA Corporation",
        AMZN: "Amazon.com, Inc.",
        MSFT: "Microsoft Corporation",
        GOOGL: "Alphabet Inc.",
        GOOG: "Alphabet Inc.",
        META: "Meta Platforms, Inc.",
        SPY: "SPDR S&P 500 ETF Trust",
        QQQ: "Invesco QQQ Trust",
        AMD: "Advanced Micro Devices"
      };
      if (!companyName && KNOWN_NAMES[symbol]) {
        companyName = KNOWN_NAMES[symbol];
      }
      return res.json({
        symbol,
        name: companyName || symbol,
        price: Number(data.c ?? 0),
        change: Number(data.d ?? 0),
        percentChange: Number(data.dp ?? 0),
        high: Number(data.h ?? 0),
        low: Number(data.l ?? 0),
        open: Number(data.o ?? 0),
        previousClose: Number(data.pc ?? 0),
        timestamp: (data.t ?? Math.floor(Date.now() / 1e3)) * 1e3
      });
    } catch (err) {
      console.error("Error fetching stock quote:", err);
      const message = err instanceof Error ? err.message : "Unknown error";
      return res.status(500).json({ error: `Failed to fetch quote: ${message}` });
    }
  });
  app.get("/api/search", async (req, res) => {
    try {
      const query = String(req.query.q || "").trim();
      if (!query) {
        return res.json({ result: [] });
      }
      const apiKey = process.env.FINNHUB_API_KEY || "dagh4ghr01quf8muaal0dagh4ghr01quf8muaalg";
      const response = await fetch(
        `https://finnhub.io/api/v1/search?q=${encodeURIComponent(query)}&token=${apiKey}`
      );
      if (!response.ok) {
        return res.status(response.status).json({ error: "Search failed" });
      }
      const data = await response.json();
      return res.json(data);
    } catch (err) {
      console.error("Error searching symbol:", err);
      return res.status(500).json({ error: "Failed to search symbols" });
    }
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    const safeHot = {
      send: () => {
      },
      on: () => {
      },
      off: () => {
      },
      listen: () => {
      },
      close: () => {
      }
    };
    const clientEnv = vite.environments?.client;
    if (clientEnv && !clientEnv.hot) {
      clientEnv.hot = safeHot;
    }
    if (vite.ws && !vite.ws.send) {
      vite.ws.send = () => {
      };
    }
    if (!vite.hot) {
      vite.hot = safeHot;
    }
    app.use((req, res, next) => {
      if (req.path === "/sw.js" || req.path === "/registerSW.js" || req.accepts("html")) {
        res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
        res.setHeader("Pragma", "no-cache");
        res.setHeader("Expires", "0");
      }
      next();
    });
    app.use(vite.middlewares);
    app.use((err, req, res, next) => {
      console.error("Server request error:", err);
      if (!res.headersSent) {
        res.status(500).send(err?.message || "Internal Server Error");
      }
    });
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
