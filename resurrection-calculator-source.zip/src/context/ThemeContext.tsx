import React, { createContext, useContext, useState, useEffect } from 'react';
import { detectPlatform, isAndroidPlatform, PlatformOS } from '../utils/platform';

export type ThemeStyle = 'material' | 'swiss' | 'terminal' | 'cyber';
export type ThemeMode = 'light' | 'dark';

interface ThemeContextType {
  style: ThemeStyle;
  mode: ThemeMode;
  platform: PlatformOS;
  setStyle: (style: ThemeStyle) => void;
  setMode: (mode: ThemeMode) => void;
  toggleMode: () => void;
  themeClasses: ThemeClasses;
}

export interface ThemeClasses {
  pageBg: string;
  cardBg: string;
  cardBorder: string;
  cardHover: string;
  textPrimary: string;
  textSecondary: string;
  textMuted: string;
  accentText: string;
  accentBg: string;
  accentBorder: string;
  accentGlow: string;
  inputBg: string;
  inputBorder: string;
  inputText: string;
  inputFocusRing: string;
  navBg: string;
  navBorder: string;
  tagBg: string;
  divider: string;
  badgeGreen: string;
  badgeRose: string;
  badgeBlue: string;
  badgeAmber: string;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

const THEME_STORAGE_KEY = 'resurrection_theme_config_v2';

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [platform] = useState<PlatformOS>(() => detectPlatform());

  const [style, setStyle] = useState<ThemeStyle>(() => {
    try {
      const saved = localStorage.getItem(THEME_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (['material', 'swiss', 'terminal', 'cyber'].includes(parsed.style)) {
          return parsed.style;
        }
      }
    } catch {
      // fallback
    }

    // Default: If running on Android, default to Material 3 Design
    // If running on Windows, default to Swiss / Windows Fluent
    if (isAndroidPlatform()) {
      return 'material';
    }
    return 'swiss';
  });

  const [mode, setMode] = useState<ThemeMode>(() => {
    try {
      const saved = localStorage.getItem(THEME_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (['light', 'dark'].includes(parsed.mode)) return parsed.mode;
      }
    } catch {
      // fallback
    }
    return 'light';
  });

  useEffect(() => {
    try {
      localStorage.setItem(THEME_STORAGE_KEY, JSON.stringify({ style, mode }));
    } catch {
      // ignore
    }

    // Apply class to root HTML element for system consistency
    if (mode === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }

    if (style === 'material') {
      document.documentElement.classList.add('theme-material');
    } else {
      document.documentElement.classList.remove('theme-material');
    }
  }, [style, mode]);

  const toggleMode = () => {
    setMode((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  const getThemeClasses = (): ThemeClasses => {
    // 1. MATERIAL 3 / MATERIAL YOU (Android Design System)
    if (style === 'material') {
      if (mode === 'dark') {
        return {
          pageBg: 'bg-[#141218] text-[#e6e0e9]',
          cardBg: 'bg-[#1d1b20]',
          cardBorder: 'border-[#49454f]/50',
          cardHover: 'hover:border-[#6750a4]/60',
          textPrimary: 'text-[#e6e0e9]',
          textSecondary: 'text-[#cac4d0]',
          textMuted: 'text-[#938f99]',
          accentText: 'text-[#d0bcff]',
          accentBg: 'bg-[#d0bcff] text-[#381e72] font-semibold',
          accentBorder: 'border-[#d0bcff]/40',
          accentGlow: 'shadow-[0_4px_20px_rgba(208,188,255,0.15)]',
          inputBg: 'bg-[#211f26]',
          inputBorder: 'border-[#49454f]',
          inputText: 'text-[#e6e0e9]',
          inputFocusRing: 'focus-within:border-[#d0bcff] focus-within:ring-2 focus-within:ring-[#d0bcff]/20',
          navBg: 'bg-[#1d1b20]/95 backdrop-blur-md',
          navBorder: 'border-[#49454f]/40',
          tagBg: 'bg-[#4a4458]/40 text-[#e8def8] border border-[#49454f]/40',
          divider: 'border-[#49454f]/40',
          badgeGreen: 'bg-[#0f5223]/70 text-[#75f893] border border-[#1b6d33]',
          badgeRose: 'bg-[#601410]/70 text-[#f2b8b5] border border-[#8c1d18]',
          badgeBlue: 'bg-[#004a77]/70 text-[#a8c7fa] border border-[#00639b]',
          badgeAmber: 'bg-[#4f3700]/70 text-[#ffdf99] border border-[#6d4c00]',
        };
      } else {
        // Material 3 Light Mode (Tonal surface, M3 Purple / Violet primary)
        return {
          pageBg: 'bg-[#fef7ff] text-[#1d1b20]',
          cardBg: 'bg-[#f7f2fa]',
          cardBorder: 'border-[#cac4d0]/60',
          cardHover: 'hover:border-[#6750a4]/60',
          textPrimary: 'text-[#1d1b20]',
          textSecondary: 'text-[#49454f]',
          textMuted: 'text-[#79747e]',
          accentText: 'text-[#6750a4]',
          accentBg: 'bg-[#6750a4] text-white font-semibold',
          accentBorder: 'border-[#6750a4]/30',
          accentGlow: 'shadow-[0_4px_16px_rgba(103,80,164,0.18)]',
          inputBg: 'bg-[#ece6f0]',
          inputBorder: 'border-[#79747e]/60',
          inputText: 'text-[#1d1b20]',
          inputFocusRing: 'focus-within:border-[#6750a4] focus-within:ring-2 focus-within:ring-[#6750a4]/20',
          navBg: 'bg-[#f3edf7]/95 backdrop-blur-md',
          navBorder: 'border-[#cac4d0]/60',
          tagBg: 'bg-[#e8def8] text-[#1d192b] border border-[#cac4d0]/50',
          divider: 'border-[#cac4d0]/50',
          badgeGreen: 'bg-[#c4eed0] text-[#072711] border border-[#a8dab5]',
          badgeRose: 'bg-[#f9dedc] text-[#410e0b] border border-[#f2b8b5]',
          badgeBlue: 'bg-[#c2e7ff] text-[#001d35] border border-[#a8c7fa]',
          badgeAmber: 'bg-[#ffdf99] text-[#261900] border border-[#ffd566]',
        };
      }
    }

    // 2. TERMINAL PRO
    if (style === 'terminal') {
      if (mode === 'dark') {
        return {
          pageBg: 'bg-[#090a0d] text-emerald-400 font-mono',
          cardBg: 'bg-[#111318]',
          cardBorder: 'border-[#1e232d]',
          cardHover: 'hover:border-emerald-500/40',
          textPrimary: 'text-emerald-300',
          textSecondary: 'text-emerald-500/80',
          textMuted: 'text-emerald-700',
          accentText: 'text-emerald-400',
          accentBg: 'bg-emerald-500 text-black font-bold',
          accentBorder: 'border-emerald-500/30',
          accentGlow: 'shadow-[0_0_15px_rgba(16,185,129,0.2)]',
          inputBg: 'bg-[#090a0d]',
          inputBorder: 'border-emerald-900/60',
          inputText: 'text-emerald-300',
          inputFocusRing: 'focus-within:border-emerald-400 focus-within:ring-1 focus-within:ring-emerald-400/30',
          navBg: 'bg-[#0d0f14]/95 backdrop-blur-md',
          navBorder: 'border-[#1e232d]',
          tagBg: 'bg-emerald-950/40 text-emerald-400 border border-emerald-800/50',
          divider: 'border-emerald-950/80',
          badgeGreen: 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/60',
          badgeRose: 'bg-rose-950/60 text-rose-300 border border-rose-800/60',
          badgeBlue: 'bg-cyan-950/60 text-cyan-300 border border-cyan-800/60',
          badgeAmber: 'bg-amber-950/60 text-amber-300 border border-amber-800/60',
        };
      } else {
        return {
          pageBg: 'bg-[#f4f2eb] text-stone-900 font-mono',
          cardBg: 'bg-[#faf8f2]',
          cardBorder: 'border-[#dfdbd0]',
          cardHover: 'hover:border-stone-400',
          textPrimary: 'text-stone-900',
          textSecondary: 'text-stone-600',
          textMuted: 'text-stone-500',
          accentText: 'text-emerald-800',
          accentBg: 'bg-emerald-700 text-white font-bold',
          accentBorder: 'border-emerald-700/30',
          accentGlow: 'shadow-sm',
          inputBg: 'bg-[#fffdf8]',
          inputBorder: 'border-stone-300',
          inputText: 'text-stone-900',
          inputFocusRing: 'focus-within:border-emerald-700 focus-within:ring-1 focus-within:ring-emerald-700/20',
          navBg: 'bg-[#faf8f2]/95 backdrop-blur-md',
          navBorder: 'border-[#dfdbd0]',
          tagBg: 'bg-stone-200/60 text-stone-800 border border-stone-300',
          divider: 'border-stone-200',
          badgeGreen: 'bg-emerald-100 text-emerald-900 border border-emerald-200',
          badgeRose: 'bg-rose-100 text-rose-900 border border-rose-200',
          badgeBlue: 'bg-cyan-100 text-cyan-900 border border-cyan-200',
          badgeAmber: 'bg-amber-100 text-amber-900 border border-amber-200',
        };
      }
    }

    // 3. CYBERPUNK HUD
    if (style === 'cyber') {
      if (mode === 'dark') {
        return {
          pageBg: 'bg-[#060a14] text-cyan-300',
          cardBg: 'bg-[#0c1424]',
          cardBorder: 'border-cyan-900/60',
          cardHover: 'hover:border-cyan-400/50',
          textPrimary: 'text-white',
          textSecondary: 'text-cyan-400/80',
          textMuted: 'text-cyan-700',
          accentText: 'text-cyan-400',
          accentBg: 'bg-gradient-to-r from-cyan-500 to-teal-400 text-black font-bold',
          accentBorder: 'border-cyan-400/40',
          accentGlow: 'shadow-[0_0_20px_rgba(6,182,212,0.25)]',
          inputBg: 'bg-[#080d1a]',
          inputBorder: 'border-cyan-900/80',
          inputText: 'text-cyan-200',
          inputFocusRing: 'focus-within:border-cyan-400 focus-within:ring-1 focus-within:ring-cyan-400/40',
          navBg: 'bg-[#0a101f]/95 backdrop-blur-md',
          navBorder: 'border-cyan-950',
          tagBg: 'bg-cyan-950/50 text-cyan-300 border border-cyan-800/40',
          divider: 'border-cyan-950',
          badgeGreen: 'bg-teal-950/60 text-teal-300 border border-teal-800/60',
          badgeRose: 'bg-pink-950/60 text-pink-300 border border-pink-800/60',
          badgeBlue: 'bg-cyan-950/60 text-cyan-300 border border-cyan-800/60',
          badgeAmber: 'bg-amber-950/60 text-amber-300 border border-amber-800/60',
        };
      } else {
        return {
          pageBg: 'bg-[#f0f5fc] text-slate-900',
          cardBg: 'bg-white',
          cardBorder: 'border-cyan-200/80',
          cardHover: 'hover:border-cyan-400',
          textPrimary: 'text-slate-900',
          textSecondary: 'text-cyan-800',
          textMuted: 'text-slate-400',
          accentText: 'text-cyan-600',
          accentBg: 'bg-cyan-600 text-white font-bold',
          accentBorder: 'border-cyan-600/30',
          accentGlow: 'shadow-md shadow-cyan-600/20',
          inputBg: 'bg-cyan-50/40',
          inputBorder: 'border-cyan-200',
          inputText: 'text-slate-900',
          inputFocusRing: 'focus-within:border-cyan-500 focus-within:ring-1 focus-within:ring-cyan-500/30',
          navBg: 'bg-white/95 backdrop-blur-md',
          navBorder: 'border-cyan-100',
          tagBg: 'bg-cyan-50 text-cyan-800 border border-cyan-200',
          divider: 'border-cyan-100',
          badgeGreen: 'bg-teal-50 text-teal-700 border border-teal-200',
          badgeRose: 'bg-rose-50 text-rose-700 border border-rose-200',
          badgeBlue: 'bg-cyan-50 text-cyan-700 border border-cyan-200',
          badgeAmber: 'bg-amber-50 text-amber-800 border border-amber-200',
        };
      }
    }

    // 4. Default: Swiss Fintech / Windows 11 Fluent Clean
    if (mode === 'dark') {
      return {
        pageBg: 'bg-slate-950 text-slate-100',
        cardBg: 'bg-slate-900',
        cardBorder: 'border-slate-800',
        cardHover: 'hover:border-slate-700',
        textPrimary: 'text-slate-100',
        textSecondary: 'text-slate-400',
        textMuted: 'text-slate-500',
        accentText: 'text-emerald-400',
        accentBg: 'bg-emerald-600 text-white font-semibold',
        accentBorder: 'border-emerald-500/30',
        accentGlow: 'shadow-lg shadow-emerald-950/50',
        inputBg: 'bg-slate-950',
        inputBorder: 'border-slate-800',
        inputText: 'text-slate-100',
        inputFocusRing: 'focus-within:border-emerald-500 focus-within:ring-1 focus-within:ring-emerald-500/20',
        navBg: 'bg-slate-900/95 backdrop-blur-md',
        navBorder: 'border-slate-800',
        tagBg: 'bg-slate-800 text-slate-300 border border-slate-700',
        divider: 'border-slate-800',
        badgeGreen: 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/60',
        badgeRose: 'bg-rose-950/60 text-rose-300 border border-rose-800/60',
        badgeBlue: 'bg-blue-950/60 text-blue-300 border border-blue-800/60',
        badgeAmber: 'bg-amber-950/60 text-amber-300 border border-amber-800/60',
      };
    } else {
      return {
        pageBg: 'bg-slate-50 text-slate-900',
        cardBg: 'bg-white',
        cardBorder: 'border-slate-200/80',
        cardHover: 'hover:border-slate-300',
        textPrimary: 'text-slate-900',
        textSecondary: 'text-slate-600',
        textMuted: 'text-slate-400',
        accentText: 'text-emerald-600',
        accentBg: 'bg-emerald-600 text-white font-semibold',
        accentBorder: 'border-emerald-600/30',
        accentGlow: 'shadow-md shadow-emerald-600/20',
        inputBg: 'bg-slate-50/50',
        inputBorder: 'border-slate-200/90',
        inputText: 'text-slate-900',
        inputFocusRing: 'focus-within:border-emerald-500 focus-within:ring-2 focus-within:ring-emerald-500/10',
        navBg: 'bg-white/90 backdrop-blur-md',
        navBorder: 'border-slate-200/80',
        tagBg: 'bg-slate-100 text-slate-600',
        divider: 'border-slate-100',
        badgeGreen: 'bg-emerald-50 text-emerald-700 border border-emerald-100',
        badgeRose: 'bg-rose-50 text-rose-700 border border-rose-100/80',
        badgeBlue: 'bg-blue-50 text-blue-700 border border-blue-100/80',
        badgeAmber: 'bg-amber-50 text-amber-800 border border-amber-200',
      };
    }
  };

  return (
    <ThemeContext.Provider
      value={{
        style,
        mode,
        platform,
        setStyle,
        setMode,
        toggleMode,
        themeClasses: getThemeClasses(),
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = (): ThemeContextType => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};
