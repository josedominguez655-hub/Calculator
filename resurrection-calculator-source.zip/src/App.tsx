import { useState, useEffect } from 'react';
import { WindowsTitleBar } from './components/WindowsTitleBar';
import { WindowsCommandBar } from './components/WindowsCommandBar';
import { WindowsStatusBar } from './components/WindowsStatusBar';
import { WindowsShortcutsModal } from './components/WindowsShortcutsModal';
import { DownloadAndModifyModal } from './components/DownloadAndModifyModal';
import { CalculatorForm } from './components/CalculatorForm';
import { ResultsPanel } from './components/ResultsPanel';
import { FormulaCard } from './components/FormulaCard';
import { HistoryView } from './components/HistoryView';
import { SettingsView } from './components/SettingsView';
import { Navigation } from './components/Navigation';
import { OfflineIndicator } from './components/OfflineIndicator';
import { ThemeProvider, useTheme } from './context/ThemeContext';
import { useKeyboardShortcuts } from './hooks/useKeyboardShortcuts';
import {
  calculateResurrection,
  formatPercent,
  PRESET_SPREADSHEET_EXACT,
  PRESET_STANDARD_FORMULA,
} from './utils/calculator';
import { ActiveTab, CalculationResult, PositionInput, SavedCalculation } from './types';

const STORAGE_KEY = 'resurrection_calc_history_v1';

function CalculatorApp() {
  const { themeClasses, mode, style, platform, toggleMode } = useTheme();
  const [activeTab, setActiveTab] = useState<ActiveTab>('calculator');
  const [input, setInput] = useState<PositionInput>(PRESET_SPREADSHEET_EXACT);
  const [result, setResult] = useState<CalculationResult | null>(() => {
    try {
      return calculateResurrection(PRESET_SPREADSHEET_EXACT);
    } catch {
      return null;
    }
  });
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<SavedCalculation[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [isSaved, setIsSaved] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string>(
    platform === 'android' ? 'Listo • Android Material 3' : 'Listo • Windows 11 Fluent App'
  );
  const [isShortcutsModalOpen, setIsShortcutsModalOpen] = useState(false);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);

  // Sync history to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
    } catch {
      // ignore storage errors
    }
  }, [history]);

  const handleCalculate = () => {
    try {
      setError(null);
      const calculated = calculateResurrection(input);
      setResult(calculated);
      setIsSaved(false);
      setStatusMessage(
        `Calculado: Comprar ${calculated.roundedShares} acciones para diluir pérdida a ${formatPercent(calculated.targetLossPercent, 1)}`
      );
    } catch (err: unknown) {
      if (err instanceof Error) {
        setError(err.message);
        setStatusMessage(`Error en cálculo: ${err.message}`);
      } else {
        setError('Ocurrió un error al calcular la fórmula.');
        setStatusMessage('Error al calcular');
      }
    }
  };

  const handleSave = () => {
    if (!result) return;
    const newItem: SavedCalculation = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      timestamp: Date.now(),
      symbol: input.symbol || 'POSITION',
      companyName: input.companyName,
      input: { ...input },
      result: { ...result, symbol: input.symbol, companyName: input.companyName },
    };
    setHistory((prev) => [newItem, ...prev]);
    setIsSaved(true);
    setStatusMessage(`Escenario guardado en el historial (${history.length + 1} registrados)`);
  };

  const handleLoadSaved = (saved: SavedCalculation) => {
    setInput(saved.input);
    setResult(saved.result);
    setError(null);
    setIsSaved(true);
    setActiveTab('calculator');
    setStatusMessage(`Cargado: ${saved.symbol || 'Posición'}`);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDeleteHistory = (id: string) => {
    setHistory((prev) => prev.filter((item) => item.id !== id));
    setStatusMessage('Cálculo eliminado del historial');
  };

  const handleClearHistory = () => {
    if (window.confirm('¿Borrar todo el historial de cálculos guardados?')) {
      setHistory([]);
      setStatusMessage('Historial vaciado');
    }
  };

  const handleLoadSpreadsheetPreset = () => {
    setInput(PRESET_SPREADSHEET_EXACT);
    try {
      const calc = calculateResurrection(PRESET_SPREADSHEET_EXACT);
      setResult(calc);
      setError(null);
      setIsSaved(false);
      setStatusMessage('Plantilla Excel cargada (234 acciones)');
    } catch (err: unknown) {
      if (err instanceof Error) setError(err.message);
    }
    setActiveTab('calculator');
  };

  const handleLoadFormulaPreset = () => {
    setInput(PRESET_STANDARD_FORMULA);
    try {
      const calc = calculateResurrection(PRESET_STANDARD_FORMULA);
      setResult(calc);
      setError(null);
      setIsSaved(false);
      setStatusMessage('Plantilla Estándar 2% cargada (180 acciones)');
    } catch (err: unknown) {
      if (err instanceof Error) setError(err.message);
    }
    setActiveTab('calculator');
  };

  const handleReset = () => {
    setInput({
      symbol: '',
      companyName: undefined,
      shares1: 0,
      originalPrice: 0,
      lossPercent: 0,
      reductionPercent: 0,
      targetLossPercent: 0,
      mode: 'reduction',
      currentPriceOverride: undefined,
    });
    setResult(null);
    setError(null);
    setIsSaved(false);
    setStatusMessage('Valores reiniciados a 0. Listo para nueva acción.');
    const symbolInput = document.getElementById('input-symbol');
    if (symbolInput) {
      symbolInput.focus();
    }
  };

  const handleResetAll = () => {
    if (window.confirm('¿Restablecer todos los datos guardados y volver al inicio?')) {
      setHistory([]);
      localStorage.removeItem(STORAGE_KEY);
      handleLoadSpreadsheetPreset();
      setActiveTab('calculator');
      setStatusMessage('Sistema restablecido');
    }
  };

  const handleFocusSearch = () => {
    if (activeTab !== 'calculator') {
      setActiveTab('calculator');
    }
    setTimeout(() => {
      const el = document.getElementById('input-symbol');
      if (el) {
        el.focus();
        (el as HTMLInputElement).select?.();
      }
    }, 50);
  };

  // Enable Desktop Keyboard Shortcuts
  useKeyboardShortcuts({
    onCalculate: handleCalculate,
    onSave: handleSave,
    onReset: handleReset,
    onFocusSearch: handleFocusSearch,
    onToggleTheme: toggleMode,
    onSetTab: setActiveTab,
    onOpenShortcuts: () => setIsShortcutsModalOpen(true),
  });

  const getBackgroundClass = () => {
    if (style === 'material') {
      return mode === 'dark' ? 'material-surface-dark text-[#e6e0e9]' : 'material-surface-light text-[#1d1b20]';
    }
    return mode === 'dark' ? 'windows-mica-dark text-slate-100' : 'windows-mica-light text-slate-900';
  };

  return (
    <div
      className={`min-h-screen ${getBackgroundClass()} pb-20 lg:pb-10 transition-colors duration-150 flex flex-col`}
    >
      {/* 1. Native Windows 11 Title Bar with Controls & Ticker info */}
      <WindowsTitleBar
        symbol={input.symbol}
        companyName={input.companyName}
        onOpenShortcuts={() => setIsShortcutsModalOpen(true)}
        onOpenInstallModal={() => setIsInstallModalOpen(true)}
      />

      {/* 2. Windows 11 Command Bar / Ribbon Toolbar */}
      <WindowsCommandBar
        activeTab={activeTab}
        onChangeTab={setActiveTab}
        historyCount={history.length}
        onReset={handleReset}
        onLoadSpreadsheetPreset={handleLoadSpreadsheetPreset}
        onLoadFormulaPreset={handleLoadFormulaPreset}
        onSave={handleSave}
        isSaved={isSaved}
        canSave={!!result}
        onFocusSearch={handleFocusSearch}
      />

      {/* 3. Main Windows Workstation Body */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-3 sm:px-5 lg:px-8 py-3.5 sm:py-5">
        {activeTab === 'calculator' && (
          <div>
            {/* Desktop Workstation Dual-Pane View (Side-by-Side on wide screens) */}
            <div className="hidden lg:grid lg:grid-cols-12 lg:gap-6 items-start">
              {/* Left Column: Input Form, Real-time Ticker & Market Quotes */}
              <div className="lg:col-span-6 space-y-4">
                <CalculatorForm
                  input={input}
                  onChange={(newInput) => {
                    setInput(newInput);
                    setIsSaved(false);
                    setStatusMessage(`Modificando: ${newInput.symbol || 'posición'}`);
                  }}
                  onCalculate={handleCalculate}
                  onResetToZero={handleReset}
                  error={error}
                />
              </div>

              {/* Right Column: Instant Results Breakdown & Formula Reference */}
              <div className="lg:col-span-6 space-y-4 sticky top-14">
                <ResultsPanel
                  result={result}
                  symbol={input.symbol}
                  companyName={input.companyName}
                  onSave={handleSave}
                  isSaved={isSaved}
                />

                <FormulaCard />
              </div>
            </div>

            {/* Mobile / Tablet Compact Single Column Flow */}
            <div className="lg:hidden max-w-md mx-auto space-y-3.5">
              <CalculatorForm
                input={input}
                onChange={(newInput) => {
                  setInput(newInput);
                  setIsSaved(false);
                }}
                onCalculate={handleCalculate}
                onResetToZero={handleReset}
                error={error}
              />

              <ResultsPanel
                result={result}
                symbol={input.symbol}
                companyName={input.companyName}
                onSave={handleSave}
                isSaved={isSaved}
              />

              <FormulaCard />
            </div>
          </div>
        )}

        {activeTab === 'history' && (
          <div className="max-w-4xl mx-auto">
            <HistoryView
              history={history}
              onLoad={handleLoadSaved}
              onDelete={handleDeleteHistory}
              onClear={handleClearHistory}
            />
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="max-w-xl mx-auto">
            <SettingsView onResetAll={handleResetAll} />
          </div>
        )}
      </main>

      {/* 4. Windows 11 Bottom Status Bar (Hidden on Mobile to let Material Navigation breathe) */}
      <div className="hidden sm:block">
        <WindowsStatusBar
          statusMessage={statusMessage}
          symbol={input.symbol}
          companyName={input.companyName}
          onOpenShortcuts={() => setIsShortcutsModalOpen(true)}
        />
      </div>

      {/* Mobile-only Bottom Tab Navigation with Material 3 specs */}
      <div className="lg:hidden">
        <Navigation
          activeTab={activeTab}
          onChangeTab={setActiveTab}
          historyCount={history.length}
        />
      </div>

      {/* Offline Status Toast */}
      <OfflineIndicator />

      {/* Modals */}
      <WindowsShortcutsModal
        isOpen={isShortcutsModalOpen}
        onClose={() => setIsShortcutsModalOpen(false)}
      />

      <DownloadAndModifyModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <CalculatorApp />
    </ThemeProvider>
  );
}
