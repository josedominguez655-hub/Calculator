/**
 * Platform and Operating System detection helpers.
 * Allows tailoring styling, navigation, and theme conventions
 * between Android (Material You / M3) and Windows 11 (Fluent / Mica).
 */

export type PlatformOS = 'android' | 'windows' | 'ios' | 'other';

export function detectPlatform(): PlatformOS {
  if (typeof window === 'undefined' || !navigator) return 'other';

  const userAgent = navigator.userAgent || navigator.vendor || (window as unknown as { opera?: string }).opera || '';

  // Check Android
  if (/android/i.test(userAgent)) {
    return 'android';
  }

  // Check Windows
  if (/windows nt|win32|win64/i.test(userAgent)) {
    return 'windows';
  }

  // Check iOS
  if (/ipad|iphone|ipod/.test(userAgent) && !(window as unknown as { MSStream?: unknown }).MSStream) {
    return 'ios';
  }

  // Fallback check: touch device with small screen often is mobile/Android
  if (window.innerWidth < 768 && 'ontouchstart' in window) {
    return 'android';
  }

  return 'other';
}

export function isAndroidPlatform(): boolean {
  return detectPlatform() === 'android';
}

export function isWindowsPlatform(): boolean {
  return detectPlatform() === 'windows';
}
