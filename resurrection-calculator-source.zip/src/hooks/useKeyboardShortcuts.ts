import { useEffect } from 'react';

interface UseKeyboardShortcutsProps {
  onCalculate: () => void;
  onSave: () => void;
  onReset: () => void;
  onFocusSearch: () => void;
  onToggleTheme: () => void;
  onSetTab: (tab: 'calculator' | 'history' | 'settings') => void;
  onOpenShortcuts: () => void;
}

export function useKeyboardShortcuts({
  onCalculate,
  onSave,
  onReset,
  onFocusSearch,
  onToggleTheme,
  onSetTab,
  onOpenShortcuts,
}: UseKeyboardShortcutsProps) {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const isCtrlOrCmd = e.ctrlKey || e.metaKey;

      // Ignore if user is typing in an input unless it's a specific shortcut like Ctrl+Enter or Ctrl+S
      const target = e.target as HTMLElement;
      const isTyping =
        target.tagName === 'INPUT' ||
        target.tagName === 'TEXTAREA' ||
        target.isContentEditable;

      if (isCtrlOrCmd && e.key === 'Enter') {
        e.preventDefault();
        onCalculate();
        return;
      }

      if (isCtrlOrCmd && (e.key === 's' || e.key === 'S')) {
        e.preventDefault();
        onSave();
        return;
      }

      if (isCtrlOrCmd && e.key === '0') {
        e.preventDefault();
        onReset();
        return;
      }

      if (isCtrlOrCmd && (e.key === 'k' || e.key === 'K')) {
        e.preventDefault();
        onFocusSearch();
        return;
      }

      if (isCtrlOrCmd && (e.key === 'd' || e.key === 'D')) {
        e.preventDefault();
        onToggleTheme();
        return;
      }

      if (isCtrlOrCmd && e.key === '1') {
        e.preventDefault();
        onSetTab('calculator');
        return;
      }

      if (isCtrlOrCmd && e.key === '2') {
        e.preventDefault();
        onSetTab('history');
        return;
      }

      if (isCtrlOrCmd && e.key === '3') {
        e.preventDefault();
        onSetTab('settings');
        return;
      }

      if (e.key === 'F1') {
        e.preventDefault();
        onOpenShortcuts();
        return;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    onCalculate,
    onSave,
    onReset,
    onFocusSearch,
    onToggleTheme,
    onSetTab,
    onOpenShortcuts,
  ]);
}
