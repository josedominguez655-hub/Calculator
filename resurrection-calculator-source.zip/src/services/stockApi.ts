export interface StockQuote {
  symbol: string;
  name?: string;
  price: number;
  change: number;
  percentChange: number;
  high: number;
  low: number;
  open: number;
  previousClose: number;
  timestamp: number;
  fromCache?: boolean;
}

export const KNOWN_STOCKS: Record<string, string> = {
  TSLA: 'Tesla, Inc.',
  AAPL: 'Apple Inc.',
  NVDA: 'NVIDIA Corporation',
  AMZN: 'Amazon.com, Inc.',
  MSFT: 'Microsoft Corporation',
  GOOGL: 'Alphabet Inc. (Google)',
  GOOG: 'Alphabet Inc. (Google)',
  META: 'Meta Platforms, Inc.',
  SPY: 'SPDR S&P 500 ETF Trust',
  QQQ: 'Invesco QQQ Trust (Nasdaq 100)',
  AMD: 'Advanced Micro Devices',
  NFLX: 'Netflix, Inc.',
  BABA: 'Alibaba Group',
  INTC: 'Intel Corporation',
  PLTR: 'Palantir Technologies',
  COIN: 'Coinbase Global',
  DIS: 'Walt Disney Company',
  V: 'Visa Inc.',
  JPM: 'JPMorgan Chase & Co.',
  BAC: 'Bank of America',
  WMT: 'Walmart Inc.',
  XOM: 'Exxon Mobil Corporation',
  CVX: 'Chevron Corporation',
  NKE: 'Nike, Inc.',
  PFE: 'Pfizer Inc.',
  SOFI: 'SoFi Technologies',
  UBER: 'Uber Technologies',
  RIVN: 'Rivian Automotive',
  LCID: 'Lucid Group',
  IWM: 'iShares Russell 2000 ETF',
  VOO: 'Vanguard S&P 500 ETF',
  VTI: 'Vanguard Total Stock ETF',
};

export function getKnownStockName(symbol: string): string | undefined {
  if (!symbol) return undefined;
  return KNOWN_STOCKS[symbol.trim().toUpperCase()];
}

const QUOTES_CACHE_KEY = 'resurrection_stock_quotes_cache_v1';

function getLocalQuoteCache(): Record<string, StockQuote> {
  try {
    const raw = localStorage.getItem(QUOTES_CACHE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function saveLocalQuoteCache(quote: StockQuote) {
  try {
    const cache = getLocalQuoteCache();
    cache[quote.symbol] = quote;
    localStorage.setItem(QUOTES_CACHE_KEY, JSON.stringify(cache));
  } catch {
    // ignore local storage quota issues
  }
}

const FINNHUB_PUBLIC_TOKEN = 'dagh4ghr01quf8muaal0dagh4ghr01quf8muaalg';

async function fetchDirectFromFinnhub(symbol: string): Promise<StockQuote> {
  const quoteUrl = `https://finnhub.io/api/v1/quote?symbol=${encodeURIComponent(symbol)}&token=${FINNHUB_PUBLIC_TOKEN}`;
  const profileUrl = `https://finnhub.io/api/v1/stock/profile2?symbol=${encodeURIComponent(symbol)}&token=${FINNHUB_PUBLIC_TOKEN}`;

  const [quoteRes, profileRes] = await Promise.all([
    fetch(quoteUrl),
    fetch(profileUrl).catch(() => null),
  ]);

  if (!quoteRes.ok) {
    throw new Error(`Finnhub API responded with status ${quoteRes.status}`);
  }

  const data = (await quoteRes.json()) as {
    c?: number;
    d?: number;
    dp?: number;
    h?: number;
    l?: number;
    o?: number;
    pc?: number;
    t?: number;
  };

  if (!data || (data.c === 0 && data.pc === 0 && data.h === 0)) {
    throw new Error(`No market quote found for "${symbol}". Please check the ticker symbol.`);
  }

  let companyName = getKnownStockName(symbol);
  if (profileRes && profileRes.ok) {
    try {
      const profileData = (await profileRes.json()) as { name?: string };
      if (profileData && profileData.name) {
        companyName = profileData.name;
      }
    } catch {
      // ignore
    }
  }

  const quote: StockQuote = {
    symbol,
    name: companyName,
    price: Number((data.c ?? 0).toFixed(2)),
    change: Number((data.d ?? 0).toFixed(2)),
    percentChange: Number((data.dp ?? 0).toFixed(2)),
    high: Number((data.h ?? 0).toFixed(2)),
    low: Number((data.l ?? 0).toFixed(2)),
    open: Number((data.o ?? 0).toFixed(2)),
    previousClose: Number((data.pc ?? 0).toFixed(2)),
    timestamp: (data.t ?? 0) * 1000 || Date.now(),
  };

  return quote;
}

export async function fetchStockQuote(symbol: string): Promise<StockQuote> {
  const cleanSymbol = symbol.trim().toUpperCase();
  if (!cleanSymbol) {
    throw new Error('Please enter a stock ticker symbol.');
  }

  // Check if navigator is offline upfront
  const isOffline = typeof navigator !== 'undefined' && !navigator.onLine;

  if (isOffline) {
    const cached = getLocalQuoteCache()[cleanSymbol];
    if (cached) {
      return { 
        ...cached, 
        name: cached.name || getKnownStockName(cleanSymbol),
        fromCache: true 
      };
    }
    throw new Error(
      `You are currently offline, and no cached price was found for "${cleanSymbol}". Please enter the price manually.`
    );
  }

  // Step 1: Try local backend /api/quote (works in web server environment)
  try {
    const response = await fetch(`/api/quote?symbol=${encodeURIComponent(cleanSymbol)}`, {
      headers: { Accept: 'application/json' },
    });
    
    if (response.ok) {
      const quote: StockQuote = await response.json();
      if (!quote.name) {
        quote.name = getKnownStockName(cleanSymbol);
      }
      saveLocalQuoteCache(quote);
      return quote;
    }
  } catch {
    // If backend route is not reachable (e.g. running in standalone Android APK WebView),
    // proceed to direct Finnhub client fetch below.
  }

  // Step 2: Fallback to direct Finnhub API (essential for Android native APK and static deployments)
  try {
    const directQuote = await fetchDirectFromFinnhub(cleanSymbol);
    saveLocalQuoteCache(directQuote);
    return directQuote;
  } catch (err: unknown) {
    // Step 3: Try cached quote if network fails
    const cached = getLocalQuoteCache()[cleanSymbol];
    if (cached) {
      return { 
        ...cached, 
        name: cached.name || getKnownStockName(cleanSymbol),
        fromCache: true 
      };
    }
    if (err instanceof Error) {
      throw err;
    }
    throw new Error(`Failed to fetch quote for "${cleanSymbol}". Please verify ticker.`);
  }
}

export const POPULAR_STOCKS: Array<{ symbol: string; name: string }> = [
  { symbol: 'TSLA', name: 'Tesla' },
  { symbol: 'NVDA', name: 'Nvidia' },
  { symbol: 'AAPL', name: 'Apple' },
  { symbol: 'AMZN', name: 'Amazon' },
  { symbol: 'MSFT', name: 'Microsoft' },
  { symbol: 'SPY', name: 'S&P 500' },
  { symbol: 'QQQ', name: 'Nasdaq' },
  { symbol: 'AMD', name: 'AMD' },
];

export const POPULAR_TICKERS = POPULAR_STOCKS.map((s) => s.symbol);
