import React, { useState } from 'react';
import { FlaskConical, ChevronRight, X, BookOpen } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

export const FormulaCard: React.FC = () => {
  const [showModal, setShowModal] = useState(false);
  const { themeClasses } = useTheme();

  return (
    <>
      <div className={`rounded-2xl border ${themeClasses.cardBorder} ${themeClasses.tagBg} p-4 transition-all`}>
        <div className="flex items-center justify-between mb-2.5">
          <div className="flex items-center gap-2">
            <FlaskConical className={`h-4 w-4 ${themeClasses.accentText}`} />
            <h3 className={`text-xs font-bold ${themeClasses.textPrimary} uppercase tracking-wider`}>
              Formula
            </h3>
          </div>
          <button
            type="button"
            onClick={() => setShowModal(true)}
            className={`flex items-center gap-1 text-[11px] font-bold ${themeClasses.accentText} hover:opacity-80 transition cursor-pointer`}
          >
            <span>How it works?</span>
            <ChevronRight className="h-3 w-3" />
          </button>
        </div>

        {/* The Exact Formula display */}
        <div className={`rounded-xl ${themeClasses.inputBg} border ${themeClasses.inputBorder} p-3 font-mono text-[11px] sm:text-xs ${themeClasses.textPrimary} shadow-2xs overflow-x-auto`}>
          <p className="whitespace-pre text-center leading-relaxed">
            Shares to Buy = (Shares 1 × Reduction) /<br />
            ((1 - Loss/100) × (Loss - Reduction))
          </p>
        </div>
      </div>

      {/* How it Works Modal / Explainer */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 p-0 sm:p-4 backdrop-blur-xs">
          <div className={`w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-t-3xl sm:rounded-3xl ${themeClasses.cardBg} border ${themeClasses.cardBorder} p-5 sm:p-6 shadow-2xl animate-in slide-in-from-bottom sm:zoom-in-95 duration-200`}>
            <div className={`flex items-center justify-between pb-3 border-b ${themeClasses.divider} mb-4`}>
              <div className="flex items-center gap-2">
                <BookOpen className={`h-5 w-5 ${themeClasses.accentText}`} />
                <h3 className={`text-base font-bold ${themeClasses.textPrimary}`}>
                  How the Resurrection Formula Works
                </h3>
              </div>
              <button
                onClick={() => setShowModal(false)}
                className={`rounded-lg p-1.5 ${themeClasses.textMuted} hover:${themeClasses.textPrimary} transition`}
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className={`space-y-4 text-xs ${themeClasses.textSecondary} leading-relaxed`}>
              {/* Step 1 */}
              <div className={`rounded-2xl ${themeClasses.tagBg} p-3.5 border ${themeClasses.cardBorder}`}>
                <h4 className={`font-bold ${themeClasses.textPrimary} mb-1 flex items-center gap-1.5 text-xs`}>
                  <span className={`flex h-5 w-5 items-center justify-center rounded-full ${themeClasses.accentBg} font-bold text-[10px]`}>1</span>
                  The Problem: Position Under Water
                </h4>
                <p>
                  You own an initial block of shares (<em>Shares 1</em>) that has decreased in price by a known drawdown (<em>Loss %</em>). Your capital is locked and break-even feels distant.
                </p>
              </div>

              {/* Step 2 */}
              <div className={`rounded-2xl ${themeClasses.tagBg} p-3.5 border ${themeClasses.cardBorder}`}>
                <h4 className={`font-bold ${themeClasses.textPrimary} mb-1 flex items-center gap-1.5 text-xs`}>
                  <span className={`flex h-5 w-5 items-center justify-center rounded-full ${themeClasses.accentBg} font-bold text-[10px]`}>2</span>
                  The Goal: Mathematical Dilution
                </h4>
                <p>
                  Instead of hoping the stock surges all the way back to your original entry price, you define an achievable target (either a <em>Reduction %</em> like -2.00% or a <em>Target Loss</em> like 0.66%).
                </p>
              </div>

              {/* Step 3 */}
              <div className={`rounded-2xl ${themeClasses.tagBg} p-3.5 border ${themeClasses.cardBorder}`}>
                <h4 className={`font-bold ${themeClasses.textPrimary} mb-1 flex items-center gap-1.5 text-xs`}>
                  <span className={`flex h-5 w-5 items-center justify-center rounded-full ${themeClasses.accentBg} font-bold text-[10px]`}>3</span>
                  The Closed-Form Solution
                </h4>
                <div className={`p-2.5 rounded-xl ${themeClasses.inputBg} border ${themeClasses.inputBorder} font-mono text-[11px] ${themeClasses.textPrimary} text-center my-2`}>
                  Shares 2 = (S₁ × R) ÷ [(1 - L/100) × (L - R)]
                </div>
                <p>
                  This calculates the exact minimum number of additional shares needed at the current price to drag your combined dollar-cost-average to your exact specified target.
                </p>
              </div>
            </div>

            <div className="mt-5">
              <button
                type="button"
                onClick={() => setShowModal(false)}
                className={`w-full rounded-xl ${themeClasses.accentBg} ${themeClasses.accentGlow} py-3 font-bold text-xs shadow-md transition`}
              >
                Close & Return to Calculator
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
