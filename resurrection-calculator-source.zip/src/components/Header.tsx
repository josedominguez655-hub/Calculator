import React from 'react';
import { TrendingUp, RefreshCw, Sparkles, Sun, Moon } from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';
import { useTheme } from '../context/ThemeContext';

interface HeaderProps {
  onLoadSpreadsheetPreset: () => void;
  onLoadFormulaPreset: () => void;
  onReset: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onLoadSpreadsheetPreset,
  onLoadFormulaPreset,
  onReset,
}) => {
  const { mode, toggleMode, style, setStyle, themeClasses } = useTheme();

  return (
    <header className="mb-3.5 pt-1">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <div className={`flex h-10 w-10 sm:h-11 sm:w-11 items-center justify-center rounded-2xl ${themeClasses.accentBg} ${themeClasses.accentGlow} shrink-0 transition-colors`}>
            <TrendingUp className="h-5 w-5 sm:h-6 sm:w-6 stroke-[2.5]" />
          </div>
          <div>
            <h1 className={`text-base sm:text-lg font-extrabold tracking-tight ${themeClasses.textPrimary} leading-tight`}>
              Resurrection
            </h1>
            <p className={`text-[11px] font-medium ${themeClasses.textMuted}`}>
              Loss recovery calculator
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          {/* Quick 1-Tap Light / Dark Mode Toggle */}
          <button
            id="btn-toggle-light-dark"
            type="button"
            title={mode === 'light' ? 'Switch to Dark Mode' : 'Switch to Light Mode'}
            onClick={toggleMode}
            className={`flex h-9 w-9 items-center justify-center rounded-xl border ${themeClasses.cardBorder} ${themeClasses.cardBg} ${themeClasses.textSecondary} hover:${themeClasses.textPrimary} active:scale-95 transition-all shadow-xs`}
          >
            {mode === 'light' ? (
              <Moon className="h-4 w-4" />
            ) : (
              <Sun className="h-4 w-4 text-amber-400" />
            )}
          </button>

          <PWAInstallButton variant="compact" />
          
          {/* Menu / Presets / Theme Style Dropdown */}
          <div className="relative group">
            <button
              id="btn-header-menu"
              aria-label="Presets and settings"
              className={`flex h-9 w-9 items-center justify-center rounded-xl border ${themeClasses.cardBorder} ${themeClasses.cardBg} ${themeClasses.textSecondary} shadow-xs hover:${themeClasses.textPrimary} active:scale-95 transition`}
            >
              <Sparkles className={`h-4 w-4 ${themeClasses.accentText}`} />
            </button>
            <div className={`absolute right-0 top-full mt-1.5 hidden w-64 rounded-2xl border ${themeClasses.cardBorder} ${themeClasses.cardBg} p-2.5 shadow-2xl group-hover:block z-40 transition-all`}>
              <p className={`px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider ${themeClasses.textMuted}`}>
                Color & Theme Style
              </p>
              <div className="grid grid-cols-3 gap-1 px-1 py-1">
                <button
                  type="button"
                  onClick={() => setStyle('swiss')}
                  className={`py-1.5 px-2 text-[10px] font-bold rounded-lg border text-center transition ${
                    style === 'swiss'
                      ? `${themeClasses.accentBg} shadow-xs`
                      : `${themeClasses.cardBorder} ${themeClasses.textSecondary} hover:${themeClasses.textPrimary}`
                  }`}
                >
                  Swiss
                </button>
                <button
                  type="button"
                  onClick={() => setStyle('terminal')}
                  className={`py-1.5 px-2 text-[10px] font-bold rounded-lg border text-center transition ${
                    style === 'terminal'
                      ? `${themeClasses.accentBg} shadow-xs`
                      : `${themeClasses.cardBorder} ${themeClasses.textSecondary} hover:${themeClasses.textPrimary}`
                  }`}
                >
                  Terminal
                </button>
                <button
                  type="button"
                  onClick={() => setStyle('cyber')}
                  className={`py-1.5 px-2 text-[10px] font-bold rounded-lg border text-center transition ${
                    style === 'cyber'
                      ? `${themeClasses.accentBg} shadow-xs`
                      : `${themeClasses.cardBorder} ${themeClasses.textSecondary} hover:${themeClasses.textPrimary}`
                  }`}
                >
                  Cyber
                </button>
              </div>

              <div className={`my-2 border-t ${themeClasses.divider}`} />

              <p className={`px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider ${themeClasses.textMuted}`}>
                Quick Presets
              </p>
              <button
                onClick={onLoadSpreadsheetPreset}
                className={`w-full text-left px-2.5 py-2 text-xs font-medium ${themeClasses.textPrimary} hover:${themeClasses.tagBg} rounded-lg transition`}
              >
                📊 Spreadsheet (234 shares)
              </button>
              <button
                onClick={onLoadFormulaPreset}
                className={`w-full text-left px-2.5 py-2 text-xs font-medium ${themeClasses.textPrimary} hover:${themeClasses.tagBg} rounded-lg transition`}
              >
                📐 Standard 2% (180 shares)
              </button>
              
              <div className={`my-1.5 border-t ${themeClasses.divider}`} />
              <button
                onClick={onReset}
                className={`w-full text-left px-2.5 py-1.5 text-xs text-rose-500 hover:text-rose-600 dark:text-rose-400 dark:hover:text-rose-300 rounded-lg flex items-center gap-1.5 transition font-medium`}
              >
                <RefreshCw className="h-3 w-3" /> Reset to 0 (New Stock)
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
