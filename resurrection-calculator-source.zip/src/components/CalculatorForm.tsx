import React, { useState } from 'react';
import {
  Edit3,
  Coins,
  DollarSign,
  TrendingDown,
  TrendingUp,
  Target,
  Calculator,
  AlertCircle,
  Tag,
  SlidersHorizontal,
  Search,
  RefreshCw,
  WifiOff,
  Check,
  Zap,
  RotateCcw,
} from 'lucide-react';
import { PositionInput, CalculationMode } from '../types';
import { useTheme } from '../context/ThemeContext';
import { fetchStockQuote, StockQuote, POPULAR_STOCKS, getKnownStockName } from '../services/stockApi';

interface CalculatorFormProps {
  input: PositionInput;
  onChange: (input: PositionInput) => void;
  onCalculate: () => void;
  onResetToZero?: () => void;
  error?: string | null;
}

export const CalculatorForm: React.FC<CalculatorFormProps> = ({
  input,
  onChange,
  onCalculate,
  onResetToZero,
  error,
}) => {
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [loadingQuote, setLoadingQuote] = useState(false);
  const [quoteError, setQuoteError] = useState<string | null>(null);
  const [activeQuote, setActiveQuote] = useState<StockQuote | null>(null);
  const [appliedQuoteSuccess, setAppliedQuoteSuccess] = useState(false);
  const [resetToast, setResetToast] = useState(false);
  const { themeClasses } = useTheme();

  // Derived current price for display
  const derivedPrice = input.originalPrice > 0 && input.lossPercent > 0
    ? (input.originalPrice * (1 - input.lossPercent / 100)).toFixed(2)
    : '0.00';

  const handleModeChange = (newMode: CalculationMode) => {
    if (newMode === input.mode) return;
    if (newMode === 'target') {
      const target = Math.max(0, Number((input.lossPercent - input.reductionPercent).toFixed(2)));
      onChange({ ...input, mode: 'target', targetLossPercent: target });
    } else {
      const reduction = Math.max(0.01, Number((input.lossPercent - input.targetLossPercent).toFixed(2)));
      onChange({ ...input, mode: 'reduction', reductionPercent: reduction });
    }
  };

  const handleFetchQuote = async (symbolToFetch?: string) => {
    const symbol = (symbolToFetch || input.symbol || '').trim().toUpperCase();
    if (!symbol) {
      setQuoteError('Please enter a stock ticker (e.g. AAPL, NVDA, TSLA).');
      return;
    }

    setLoadingQuote(true);
    setQuoteError(null);
    setAppliedQuoteSuccess(false);

    try {
      const quote = await fetchStockQuote(symbol);
      setActiveQuote(quote);
      
      // If originalPrice is from a previous demo (like $3.88 while ticker is $200+),
      // we update symbol but do not force mismatched math
      onChange({ ...input, symbol: quote.symbol, companyName: quote.name });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Could not fetch stock quote.';
      setQuoteError(msg);
      setActiveQuote(null);
    } finally {
      setLoadingQuote(false);
    }
  };

  // 1. Use quote as the Current Market Price (Second purchase / reduction price)
  const handleUseAsReductionPrice = () => {
    if (!activeQuote) return;
    const mktPrice = activeQuote.price;

    let updated = {
      ...input,
      symbol: activeQuote.symbol,
      companyName: activeQuote.name || input.companyName,
      currentPriceOverride: mktPrice,
    };

    // Check if initial buy price is set and realistic for this ticker
    const isMismatched = input.originalPrice <= 0 || input.originalPrice < mktPrice * 0.3 || input.originalPrice > mktPrice * 3;

    if (isMismatched) {
      // If initial buy price is from an old demo (e.g. $3.88 vs $225), set initial buy price to previous close or +3%
      const realisticBuy = activeQuote.previousClose > mktPrice
        ? activeQuote.previousClose
        : Number((mktPrice * 1.05).toFixed(2));
      updated.originalPrice = realisticBuy;
      const autoLoss = Number((((realisticBuy - mktPrice) / realisticBuy) * 100).toFixed(2));
      updated.lossPercent = Math.max(0.5, autoLoss);
      if (updated.mode === 'reduction') {
        updated.reductionPercent = Number((updated.lossPercent / 2).toFixed(2));
      } else {
        updated.targetLossPercent = Number((updated.lossPercent / 2).toFixed(2));
      }
    } else if (input.originalPrice > mktPrice) {
      // Calculate exact loss % from your initial purchase price
      const autoLoss = Number((((input.originalPrice - mktPrice) / input.originalPrice) * 100).toFixed(2));
      updated.lossPercent = autoLoss;
      if (updated.mode === 'reduction') {
        if (updated.reductionPercent >= autoLoss || updated.reductionPercent <= 0) {
          updated.reductionPercent = Number((autoLoss / 2).toFixed(2));
        }
      } else {
        if (updated.targetLossPercent >= autoLoss || updated.targetLossPercent < 0) {
          updated.targetLossPercent = Number((autoLoss / 2).toFixed(2));
        }
      }
    }

    onChange(updated);
    setAppliedQuoteSuccess(true);
    setTimeout(() => setAppliedQuoteSuccess(false), 3000);
    onCalculate();
  };

  // 2. Set quote as Initial Buy Price (First purchase)
  const handleSetAsInitialBuyPrice = () => {
    if (!activeQuote) return;
    const mktPrice = activeQuote.price;
    const updated = {
      ...input,
      symbol: activeQuote.symbol,
      companyName: activeQuote.name || input.companyName,
      originalPrice: mktPrice,
      currentPriceOverride: undefined,
    };
    onChange(updated);
    setAppliedQuoteSuccess(true);
    setTimeout(() => setAppliedQuoteSuccess(false), 3000);
    onCalculate();
  };

  const isOldPresetMismatched = activeQuote && (
    input.originalPrice <= 0 ||
    input.originalPrice < activeQuote.price * 0.3 ||
    input.originalPrice > activeQuote.price * 3
  );

  const handleResetAllValues = () => {
    setActiveQuote(null);
    setQuoteError(null);
    setAppliedQuoteSuccess(false);
    setResetToast(true);
    setTimeout(() => setResetToast(false), 3000);
    if (onResetToZero) {
      onResetToZero();
    } else {
      onChange({
        symbol: '',
        companyName: undefined,
        shares1: 0,
        originalPrice: 0,
        lossPercent: 0,
        reductionPercent: 0,
        targetLossPercent: 0,
        mode: 'reduction',
        currentPriceOverride: undefined,
      });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onCalculate();
  };

  const currentCompanyName = activeQuote?.name || input.companyName || getKnownStockName(input.symbol);

  return (
    <div className={`rounded-2xl border ${themeClasses.cardBorder} ${themeClasses.cardBg} p-4 sm:p-5 shadow-xs transition-colors`}>
      <div className={`flex items-center justify-between pb-3 border-b ${themeClasses.divider} mb-3.5`}>
        <div className="flex items-center gap-2">
          <Edit3 className={`h-4 w-4 ${themeClasses.accentText}`} />
          <h2 className={`text-sm font-bold ${themeClasses.textPrimary} tracking-tight`}>
            Input Values
          </h2>
          {input.symbol && (
            <span className="text-xs font-bold text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20">
              {input.symbol}
              {currentCompanyName ? ` • ${currentCompanyName}` : ''}
            </span>
          )}
        </div>
        
        <button
          type="button"
          id="btn-reset-top"
          onClick={handleResetAllValues}
          title="Reset all inputs to zero to start a new stock transaction"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl border border-rose-500/40 text-rose-500 bg-rose-500/10 hover:bg-rose-500 hover:text-white transition active:scale-95 cursor-pointer shadow-xs"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset to 0</span>
        </button>
      </div>

      {resetToast && (
        <div className="mb-3 flex items-center gap-2 rounded-xl bg-emerald-500/15 border border-emerald-500/30 p-2.5 text-xs text-emerald-400 font-bold animate-in fade-in">
          <Check className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>All values reset to zero! Ready for a new stock.</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-3.5">
        {/* Real-time Ticker & Market Data Bar */}
        <div className={`rounded-xl border ${themeClasses.cardBorder} ${themeClasses.tagBg} p-3 space-y-2`}>
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 flex-1 min-w-0">
              <Tag className={`w-3.5 h-3.5 ${themeClasses.accentText} shrink-0`} />
              <input
                id="input-symbol"
                type="text"
                placeholder="Ticker (e.g. TSLA, NVDA)"
                value={input.symbol}
                onChange={(e) => {
                  const sym = e.target.value.toUpperCase();
                  const name = getKnownStockName(sym);
                  onChange({ ...input, symbol: sym, companyName: name });
                  setQuoteError(null);
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleFetchQuote();
                  }
                }}
                maxLength={8}
                className={`w-20 sm:w-28 text-xs font-extrabold uppercase tracking-wider ${themeClasses.textPrimary} placeholder:${themeClasses.textMuted} focus:outline-none bg-transparent shrink-0`}
              />
              {currentCompanyName && (
                <div className="flex items-center gap-1 min-w-0 overflow-hidden">
                  <span className="text-emerald-500 font-bold text-xs shrink-0">•</span>
                  <span
                    className="text-xs font-bold text-emerald-500 truncate"
                    title={currentCompanyName}
                  >
                    {currentCompanyName}
                  </span>
                </div>
              )}
            </div>

            <button
              type="button"
              id="btn-fetch-quote"
              onClick={() => handleFetchQuote()}
              disabled={loadingQuote}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg ${themeClasses.accentBg} text-white shadow-xs hover:opacity-90 active:scale-95 disabled:opacity-50 transition cursor-pointer shrink-0`}
            >
              {loadingQuote ? (
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Search className="w-3.5 h-3.5" />
              )}
              <span>{loadingQuote ? 'Fetching...' : 'Get Live Price'}</span>
            </button>
          </div>

          {/* Quick Popular Ticker Chips with company names */}
          <div className="flex items-center gap-1.5 overflow-x-auto py-0.5 no-scrollbar">
            <span className={`text-[10px] font-semibold ${themeClasses.textMuted} shrink-0`}>Quick:</span>
            {POPULAR_STOCKS.map((stock) => (
              <button
                key={stock.symbol}
                type="button"
                onClick={() => {
                  onChange({ ...input, symbol: stock.symbol, companyName: stock.name });
                  handleFetchQuote(stock.symbol);
                }}
                title={`${stock.symbol} - ${stock.name}`}
                className={`px-2 py-0.5 rounded-md text-[10px] font-bold border transition shrink-0 flex items-center gap-1 ${
                  input.symbol === stock.symbol
                    ? `${themeClasses.accentBorder} ${themeClasses.accentText} bg-white/40`
                    : `${themeClasses.inputBorder} ${themeClasses.textMuted} hover:${themeClasses.textPrimary}`
                }`}
              >
                <span>{stock.symbol}</span>
                <span className="opacity-60 text-[9px] font-normal hidden sm:inline">({stock.name})</span>
              </button>
            ))}
          </div>

          {/* Live Quote Card when fetched */}
          {activeQuote && (
            <div className="mt-2 rounded-xl bg-slate-900 text-white border border-slate-800 p-3 space-y-2.5 animate-in fade-in slide-in-from-top-1 duration-150 shadow-sm">
              {/* Ticker header and current market price */}
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-black tracking-wider text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/40">
                      {activeQuote.symbol}
                    </span>
                    {(activeQuote.name || currentCompanyName) && (
                      <span className="text-xs font-bold text-white bg-slate-800 px-2 py-0.5 rounded-md border border-slate-700 shadow-2xs">
                        {activeQuote.name || currentCompanyName}
                      </span>
                    )}
                    <span className="text-base font-black text-white">
                      ${activeQuote.price.toFixed(2)}
                    </span>
                    <div
                      className={`inline-flex items-center gap-0.5 text-[11px] font-bold px-1.5 py-0.5 rounded-md ${
                        activeQuote.change >= 0
                          ? 'bg-emerald-500/20 text-emerald-300'
                          : 'bg-rose-500/20 text-rose-300'
                      }`}
                    >
                      {activeQuote.change >= 0 ? (
                        <TrendingUp className="w-3 h-3" />
                      ) : (
                        <TrendingDown className="w-3 h-3" />
                      )}
                      <span>
                        {activeQuote.change >= 0 ? '+' : ''}
                        {activeQuote.change.toFixed(2)} ({activeQuote.percentChange.toFixed(2)}%)
                      </span>
                    </div>
                    {activeQuote.fromCache && (
                      <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-amber-300 bg-amber-500/20 px-1.5 py-0.5 rounded-md">
                        <WifiOff className="w-2.5 h-2.5" />
                        Cached
                      </span>
                    )}
                  </div>
                  <p className="text-[10px] text-slate-400 mt-0.5">
                    Live Market Price • Used for 2nd purchase to average down
                  </p>
                </div>

                <div className="text-[10px] text-slate-400 text-right">
                  <div>Range: ${activeQuote.low.toFixed(2)} - ${activeQuote.high.toFixed(2)}</div>
                  <div>Prev Close: ${activeQuote.previousClose.toFixed(2)}</div>
                </div>
              </div>

              {/* Notice if old demo price is still in Initial Buy Price */}
              {isOldPresetMismatched && (
                <div className="rounded-lg bg-amber-500/10 border border-amber-500/20 p-2 text-[11px] text-amber-300 flex items-start gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5 text-amber-400" />
                  <div className="leading-snug">
                    <span className="font-bold">Initial price mismatch:</span> Your current Buy Price is{' '}
                    <span className="underline">${input.originalPrice}</span> (from the previous demo). Enter what you originally paid for {activeQuote.symbol} in the <b>Initial Buy Price</b> box below, or tap below to set it.
                  </div>
                </div>
              )}

              {/* Automatic Loss Calculation preview */}
              {input.originalPrice > activeQuote.price && (
                <div className="flex items-center justify-between rounded-lg bg-emerald-950/50 border border-emerald-500/30 px-2.5 py-1.5 text-xs text-emerald-300 font-medium">
                  <span>
                    Calculated Loss: <b className="text-white font-bold">-{(((input.originalPrice - activeQuote.price) / input.originalPrice) * 100).toFixed(2)}%</b> (${(input.originalPrice - activeQuote.price).toFixed(2)}/sh)
                  </span>
                  <span className="text-[10px] text-emerald-400">Auto-applied in calculation</span>
                </div>
              )}

              {/* Two explicit Action Buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                <button
                  type="button"
                  id="btn-apply-reduction-price"
                  onClick={handleUseAsReductionPrice}
                  className="inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-bold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white shadow-sm transition active:scale-98 cursor-pointer"
                >
                  <Zap className="w-3.5 h-3.5 text-emerald-200" />
                  <span>Use as Current Price (${activeQuote.price.toFixed(2)})</span>
                </button>

                <button
                  type="button"
                  id="btn-set-initial-buy-price"
                  onClick={handleSetAsInitialBuyPrice}
                  className="inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition active:scale-98 cursor-pointer"
                >
                  <DollarSign className="w-3.5 h-3.5 text-slate-400" />
                  <span>Set as Initial Buy Price (${activeQuote.price.toFixed(2)})</span>
                </button>
              </div>

              {appliedQuoteSuccess && (
                <div className="flex items-center justify-center gap-1 text-[11px] font-bold text-emerald-400 pt-0.5">
                  <Check className="w-3.5 h-3.5" />
                  <span>Applied and recalculated!</span>
                </div>
              )}
            </div>
          )}

          {/* Quote Error Notice */}
          {quoteError && (
            <div className="flex items-center gap-1.5 text-[11px] text-rose-500 bg-rose-500/10 border border-rose-500/20 px-2.5 py-1.5 rounded-lg">
              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
              <span>{quoteError}</span>
            </div>
          )}
        </div>

        {/* Mode Selector Tabs */}
        <div className="flex items-center justify-between gap-2 pt-1">
          <span className={`text-xs font-semibold ${themeClasses.textSecondary}`}>
            Calculation Target:
          </span>
          <div className={`flex rounded-lg p-0.5 text-[11px] font-semibold ${themeClasses.tagBg}`}>
            <button
              type="button"
              id="mode-reduction-tab"
              onClick={() => handleModeChange('reduction')}
              className={`px-2.5 py-1 rounded-md transition-all ${
                input.mode === 'reduction'
                  ? `${themeClasses.accentBg} shadow-xs font-bold`
                  : `${themeClasses.textMuted} hover:${themeClasses.textPrimary}`
              }`}
            >
              Reduction %
            </button>
            <button
              type="button"
              id="mode-target-tab"
              onClick={() => handleModeChange('target')}
              className={`px-2.5 py-1 rounded-md transition-all ${
                input.mode === 'target'
                  ? `${themeClasses.accentBg} shadow-xs font-bold`
                  : `${themeClasses.textMuted} hover:${themeClasses.textPrimary}`
              }`}
            >
              Target Loss %
            </button>
          </div>
        </div>

        {/* 2x2 Primary Inputs Grid */}
        <div className="grid grid-cols-2 gap-3">
          {/* Box 1: Shares 1 */}
          <div className={`rounded-xl border ${themeClasses.inputBorder} ${themeClasses.inputBg} p-2.5 ${themeClasses.inputFocusRing} transition-all`}>
            <div className="flex items-center gap-1.5 mb-1.5">
              <Coins className={`h-3.5 w-3.5 ${themeClasses.accentText}`} />
              <label htmlFor="input-shares1" className={`text-[11px] font-semibold ${themeClasses.textSecondary}`}>
                Shares 1
              </label>
            </div>
            <input
              id="input-shares1"
              type="number"
              inputMode="numeric"
              min="1"
              step="1"
              value={input.shares1 || ''}
              onChange={(e) => onChange({ ...input, shares1: Number(e.target.value) })}
              className={`w-full text-base font-bold ${themeClasses.inputText} focus:outline-none bg-transparent`}
              placeholder="75"
              required
            />
          </div>

          {/* Box 2: Price (per share) */}
          <div className={`rounded-xl border ${themeClasses.inputBorder} ${themeClasses.inputBg} p-2.5 ${themeClasses.inputFocusRing} transition-all`}>
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-1.5">
                <DollarSign className={`h-3.5 w-3.5 ${themeClasses.accentText}`} />
                <label htmlFor="input-price" className={`text-[11px] font-semibold ${themeClasses.textSecondary}`}>
                  Initial Buy Price
                </label>
              </div>
              <span className={`text-[9px] font-bold ${themeClasses.textMuted} uppercase`}>1st Purchase</span>
            </div>
            <div className="flex items-center">
              <span className={`${themeClasses.textMuted} font-semibold mr-0.5 text-sm`}>$</span>
              <input
                id="input-price"
                type="number"
                inputMode="decimal"
                min="0.0001"
                step="any"
                value={input.originalPrice || ''}
                onChange={(e) => onChange({ ...input, originalPrice: Number(e.target.value) })}
                className={`w-full text-base font-bold ${themeClasses.inputText} focus:outline-none bg-transparent`}
                placeholder="3.88"
                required
              />
            </div>
          </div>

          {/* Box 3: Loss % */}
          <div className={`rounded-xl border ${themeClasses.inputBorder} ${themeClasses.inputBg} p-2.5 ${themeClasses.inputFocusRing} transition-all`}>
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-1.5">
                <TrendingDown className="h-3.5 w-3.5 text-rose-500" />
                <label htmlFor="input-loss" className={`text-[11px] font-semibold ${themeClasses.textSecondary}`}>
                  Loss %
                </label>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <input
                id="input-loss"
                type="number"
                inputMode="decimal"
                min="0.01"
                max="99.99"
                step="any"
                value={input.lossPercent || ''}
                onChange={(e) => onChange({ ...input, lossPercent: Number(e.target.value) })}
                className={`w-full text-base font-bold ${themeClasses.inputText} focus:outline-none bg-transparent`}
                placeholder="2.86"
                required
              />
              <span className={`${themeClasses.textMuted} font-bold text-sm ml-1`}>%</span>
            </div>
          </div>

          {/* Box 4: Reduction % OR Target Loss % */}
          <div className={`rounded-xl border ${themeClasses.inputBorder} ${themeClasses.inputBg} p-2.5 ${themeClasses.inputFocusRing} transition-all`}>
            <div className="flex items-center gap-1.5 mb-1.5">
              <Target className={`h-3.5 w-3.5 ${themeClasses.accentText}`} />
              <label htmlFor="input-target-reduction" className={`text-[11px] font-semibold ${themeClasses.textSecondary} truncate`}>
                {input.mode === 'reduction' ? 'Reduction %' : 'Target Loss %'}
              </label>
            </div>
            <div className="flex items-center justify-between">
              <input
                id="input-target-reduction"
                type="number"
                inputMode="decimal"
                min="0.01"
                max="99.99"
                step="any"
                value={
                  input.mode === 'reduction'
                    ? (input.reductionPercent || '')
                    : (input.targetLossPercent || '')
                }
                onChange={(e) => {
                  const val = Number(e.target.value);
                  if (input.mode === 'reduction') {
                    onChange({ ...input, reductionPercent: val });
                  } else {
                    onChange({ ...input, targetLossPercent: val });
                  }
                }}
                className={`w-full text-base font-bold ${themeClasses.inputText} focus:outline-none bg-transparent`}
                placeholder={input.mode === 'reduction' ? '2.00' : '0.66'}
                required
              />
              <span className={`${themeClasses.textMuted} font-bold text-sm ml-1`}>%</span>
            </div>
          </div>
        </div>

        {/* Current Price and Context pill */}
        <div className="flex items-center justify-between text-xs px-1 pt-0.5">
          <div className="flex items-center gap-1.5">
            <span className={themeClasses.textMuted}>Current Market Price:</span>
            <span className={`font-semibold ${themeClasses.textPrimary}`}>
              ${input.currentPriceOverride ? input.currentPriceOverride.toFixed(2) : derivedPrice}
            </span>
            {input.currentPriceOverride && (
              <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 px-1 py-0.5 rounded">
                Live / Custom
              </span>
            )}
          </div>
          <button
            type="button"
            onClick={() => setShowAdvanced(!showAdvanced)}
            className={`flex items-center gap-1 text-[11px] font-semibold ${themeClasses.accentText} hover:opacity-80 transition`}
          >
            <SlidersHorizontal className="w-3 h-3" />
            {showAdvanced ? 'Hide manual price' : 'Manual price override'}
          </button>
        </div>

        {showAdvanced && (
          <div className={`rounded-xl ${themeClasses.tagBg} p-3 border ${themeClasses.cardBorder} text-xs animate-in fade-in duration-150`}>
            <label htmlFor="input-price-override" className={`block text-[11px] font-semibold ${themeClasses.textSecondary} mb-1`}>
              Exact Market Price Override ($)
            </label>
            <div className="flex items-center gap-2">
              <div className={`flex items-center ${themeClasses.inputBg} border ${themeClasses.inputBorder} rounded-lg px-2.5 py-1.5 flex-1`}>
                <span className={`${themeClasses.textMuted} font-semibold mr-1`}>$</span>
                <input
                  id="input-price-override"
                  type="number"
                  step="any"
                  placeholder={derivedPrice}
                  value={input.currentPriceOverride || ''}
                  onChange={(e) => onChange({ ...input, currentPriceOverride: e.target.value ? Number(e.target.value) : undefined })}
                  className={`w-full font-medium ${themeClasses.inputText} focus:outline-none text-xs bg-transparent`}
                />
              </div>
              {input.currentPriceOverride && (
                <button
                  type="button"
                  onClick={() => onChange({ ...input, currentPriceOverride: undefined })}
                  className="text-[11px] text-rose-500 hover:text-rose-600 underline"
                >
                  Clear
                </button>
              )}
            </div>
            <p className={`mt-1 text-[10px] ${themeClasses.textMuted}`}>
              Leave blank to automatically compute from Buy Price and Loss %.
            </p>
          </div>
        )}

        {/* Validation Error Alert */}
        {error && (
          <div className="flex items-start gap-2 rounded-xl bg-rose-500/10 p-3 text-xs text-rose-500 border border-rose-500/20 animate-in fade-in">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-500 mt-0.5" />
            <p className="font-medium leading-relaxed">{error}</p>
          </div>
        )}

        {/* Action Buttons: Reset to Zero + Calculate */}
        <div className="grid grid-cols-2 gap-2.5 pt-1">
          <button
            id="btn-reset-bottom"
            type="button"
            onClick={handleResetAllValues}
            className="flex items-center justify-center gap-2 rounded-xl border border-rose-500/40 bg-rose-500/10 hover:bg-rose-500 hover:text-white text-rose-500 py-3.5 px-3 text-xs font-bold active:scale-[0.99] transition cursor-pointer shadow-xs"
          >
            <RotateCcw className="h-4 w-4 shrink-0" />
            <span>Reset to 0</span>
          </button>

          <button
            id="btn-calculate"
            type="submit"
            className={`flex items-center justify-center gap-2 rounded-xl ${themeClasses.accentBg} ${themeClasses.accentGlow} py-3.5 px-4 text-sm font-bold shadow-md hover:opacity-90 active:scale-[0.99] transition-all cursor-pointer`}
          >
            <Calculator className="h-4 w-4 shrink-0" />
            <span>Calculate</span>
          </button>
        </div>
      </form>
    </div>
  );
};
