import React, { useState } from 'react';
import {
  BarChart3,
  Target,
  Tag,
  PlusCircle,
  Waves,
  Coins,
  Calculator,
  TrendingUp,
  Users,
  BookmarkPlus,
  Check,
  Copy,
  AlertTriangle,
  Info,
} from 'lucide-react';
import { CalculationResult } from '../types';
import { formatCurrency, formatPercent } from '../utils/calculator';
import { useTheme } from '../context/ThemeContext';

interface ResultsPanelProps {
  result: CalculationResult | null;
  symbol?: string;
  companyName?: string;
  onSave: () => void;
  isSaved?: boolean;
}

export const ResultsPanel: React.FC<ResultsPanelProps> = ({
  result,
  symbol,
  companyName,
  onSave,
  isSaved = false,
}) => {
  const [copied, setCopied] = useState(false);
  const [showExplanation, setShowExplanation] = useState(false);
  const { themeClasses } = useTheme();

  if (!result) {
    return (
      <div className={`rounded-2xl border border-dashed ${themeClasses.cardBorder} ${themeClasses.cardBg} p-8 text-center transition-colors`}>
        <div className={`mx-auto flex h-12 w-12 items-center justify-center rounded-2xl ${themeClasses.tagBg} ${themeClasses.textMuted} mb-3`}>
          <BarChart3 className="h-6 w-6" />
        </div>
        <h3 className={`text-sm font-bold ${themeClasses.textPrimary}`}>No Calculation Yet</h3>
        <p className={`mt-1 text-xs ${themeClasses.textMuted} max-w-xs mx-auto`}>
          Enter your current position parameters above and tap Calculate to see the required shares and recovery price.
        </p>
      </div>
    );
  }

  const stockLabel = symbol || result.symbol || '';
  const nameLabel = companyName || result.companyName || '';

  const copySummary = () => {
    const text = `Resurrection Calculator Results:
${stockLabel ? `• Stock: ${stockLabel}${nameLabel ? ` (${nameLabel})` : ''}\n` : ''}• Original: ${result.shares1} shares @ ${formatCurrency(result.originalPrice)} (${formatCurrency(result.cost1)})
• Current Loss: ${formatPercent(result.lossPercent)} → Target Loss: ${formatPercent(result.targetLossPercent)}
• Current Price: ${formatCurrency(result.currentPrice)}
• Buy: ${result.roundedShares} shares (${result.shares2} exact)
• Additional Cost: ${formatCurrency(result.cost2)}
• Total Investment: ${formatCurrency(result.totalCost)}
• New Average Price: ${formatCurrency(result.newAvgPrice)}
• Total Shares: ${result.totalShares}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className={`rounded-2xl border ${themeClasses.cardBorder} ${themeClasses.cardBg} p-4 sm:p-5 shadow-xs transition-colors`}>
      <div className={`flex items-center justify-between pb-3 border-b ${themeClasses.divider} mb-3 flex-wrap gap-2`}>
        <div className="flex items-center gap-2 flex-wrap">
          <BarChart3 className={`h-4 w-4 ${themeClasses.accentText}`} />
          <h2 className={`text-sm font-bold ${themeClasses.textPrimary} tracking-tight`}>
            Results
          </h2>
          {stockLabel && (
            <span className="text-xs font-black text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/40">
              {stockLabel}
            </span>
          )}
          {nameLabel && (
            <span className={`text-xs font-bold ${themeClasses.textSecondary}`}>
              • {nameLabel}
            </span>
          )}
        </div>
        <span className={`text-[11px] font-medium ${themeClasses.textMuted}`}>
          Based on the resurrection formula
        </span>
      </div>

      {/* Results Rows styled cleanly with adaptive theme badges */}
      <div className={`divide-y ${themeClasses.divider} text-xs`}>
        {/* Target Loss */}
        <div className="flex items-center justify-between py-2.5">
          <div className="flex items-center gap-2.5">
            <Target className="h-4 w-4 text-rose-500" />
            <span className={`font-semibold ${themeClasses.textSecondary}`}>Target Loss</span>
          </div>
          <span className={`inline-flex items-center justify-center min-w-[76px] px-3 py-1 rounded-lg font-bold ${themeClasses.badgeRose}`}>
            {formatPercent(result.targetLossPercent)}
          </span>
        </div>

        {/* Current Price */}
        <div className="flex items-center justify-between py-2.5">
          <div className="flex items-center gap-2.5">
            <Tag className="h-4 w-4 text-blue-500" />
            <span className={`font-semibold ${themeClasses.textSecondary}`}>Current Price</span>
          </div>
          <span className={`inline-flex items-center justify-center min-w-[76px] px-3 py-1 rounded-lg font-bold ${themeClasses.badgeBlue}`}>
            {result.currentPrice.toFixed(2)}
          </span>
        </div>

        {/* Shares 2 (to buy) */}
        <div className="flex items-center justify-between py-2.5">
          <div className="flex items-center gap-2.5">
            <PlusCircle className={`h-4 w-4 ${themeClasses.accentText}`} />
            <span className={`font-semibold ${themeClasses.textSecondary}`}>Shares 2 (to buy)</span>
          </div>
          <span className={`inline-flex items-center justify-center min-w-[76px] px-3 py-1 rounded-lg font-bold ${themeClasses.badgeGreen}`}>
            {result.shares2.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
        </div>

        {/* Rounded Shares */}
        <div className="flex items-center justify-between py-2.5">
          <div className="flex items-center gap-2.5">
            <Waves className={`h-4 w-4 ${themeClasses.accentText}`} />
            <span className={`font-semibold ${themeClasses.textSecondary}`}>Rounded Shares</span>
          </div>
          <span className={`inline-flex items-center justify-center min-w-[76px] px-3 py-1 rounded-lg font-extrabold ${themeClasses.accentBg} ${themeClasses.accentGlow}`}>
            {result.roundedShares.toLocaleString()}
          </span>
        </div>

        {/* Cost 1 */}
        <div className="flex items-center justify-between py-2.5">
          <div className="flex items-center gap-2.5">
            <Coins className="h-4 w-4 text-amber-500" />
            <span className={`font-semibold ${themeClasses.textSecondary}`}>Cost 1</span>
          </div>
          <span className={`inline-flex items-center justify-center min-w-[76px] px-3 py-1 rounded-lg font-bold ${themeClasses.badgeAmber}`}>
            {result.cost1.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
        </div>

        {/* Cost 2 */}
        <div className="flex items-center justify-between py-2.5">
          <div className="flex items-center gap-2.5">
            <Coins className="h-4 w-4 text-amber-600" />
            <span className={`font-semibold ${themeClasses.textSecondary}`}>Cost 2</span>
          </div>
          <span className={`inline-flex items-center justify-center min-w-[76px] px-3 py-1 rounded-lg font-bold ${themeClasses.badgeAmber}`}>
            {result.cost2.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
        </div>

        {/* Total Cost */}
        <div className="flex items-center justify-between py-2.5">
          <div className="flex items-center gap-2.5">
            <Calculator className="h-4 w-4 text-amber-600" />
            <span className={`font-semibold ${themeClasses.textSecondary}`}>Total Cost</span>
          </div>
          <span className={`inline-flex items-center justify-center min-w-[76px] px-3 py-1 rounded-lg font-black ${themeClasses.badgeAmber} shadow-xs`}>
            {result.totalCost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
        </div>

        {/* New Avg Price */}
        <div className="flex items-center justify-between py-2.5">
          <div className="flex items-center gap-2.5">
            <TrendingUp className="h-4 w-4 text-blue-500" />
            <span className={`font-semibold ${themeClasses.textSecondary}`}>New Avg Price</span>
          </div>
          <span className={`inline-flex items-center justify-center min-w-[76px] px-3 py-1 rounded-lg font-bold ${themeClasses.badgeBlue}`}>
            {result.newAvgPrice.toFixed(2)}
          </span>
        </div>

        {/* Total Shares */}
        <div className="flex items-center justify-between py-2.5">
          <div className="flex items-center gap-2.5">
            <Users className={`h-4 w-4 ${themeClasses.accentText}`} />
            <span className={`font-semibold ${themeClasses.textSecondary}`}>Total Shares</span>
          </div>
          <span className={`inline-flex items-center justify-center min-w-[76px] px-3 py-1 rounded-lg font-bold ${themeClasses.badgeGreen}`}>
            {result.totalShares.toLocaleString()}
          </span>
        </div>
      </div>

      {/* Safety & Risk Banner */}
      {result.warning && (
        <div className={`mt-3 flex items-start gap-2 rounded-xl p-3 text-xs ${themeClasses.badgeAmber}`}>
          <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold">{result.warning}</p>
            <p className="text-[11px] opacity-90 mt-0.5">
              Capital required for additional purchase is {result.capitalRatio}× the initial investment. Ensure this fits your risk management guidelines.
            </p>
          </div>
        </div>
      )}

      {/* Interactive Explanation helper & Action Buttons */}
      <div className={`mt-3.5 pt-3 border-t ${themeClasses.divider} flex items-center justify-between gap-2`}>
        <button
          type="button"
          onClick={() => setShowExplanation(!showExplanation)}
          className={`inline-flex items-center gap-1 text-[11px] font-semibold ${themeClasses.accentText} hover:opacity-80 transition`}
        >
          <Info className="w-3.5 h-3.5" />
          <span>{showExplanation ? 'Hide details' : 'Cost dilution breakdown'}</span>
        </button>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            id="btn-copy-results"
            onClick={copySummary}
            className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border ${themeClasses.cardBorder} text-[11px] font-semibold ${themeClasses.textSecondary} hover:${themeClasses.textPrimary} active:scale-95 transition`}
            title="Copy summary to clipboard"
          >
            {copied ? <Check className={`w-3.5 h-3.5 ${themeClasses.accentText}`} /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? 'Copied' : 'Copy'}
          </button>

          <button
            type="button"
            id="btn-save-history"
            onClick={onSave}
            disabled={isSaved}
            className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-[11px] font-bold transition active:scale-95 ${
              isSaved
                ? `${themeClasses.tagBg} ${themeClasses.textMuted} cursor-default`
                : `${themeClasses.accentBg} ${themeClasses.accentGlow} shadow-xs`
            }`}
          >
            {isSaved ? <Check className="w-3.5 h-3.5" /> : <BookmarkPlus className="w-3.5 h-3.5" />}
            {isSaved ? 'Saved' : 'Save'}
          </button>
        </div>
      </div>

      {showExplanation && (
        <div className={`mt-3 rounded-xl ${themeClasses.tagBg} p-3.5 text-xs ${themeClasses.textSecondary} border ${themeClasses.cardBorder} space-y-2 animate-in fade-in`}>
          <h4 className={`font-bold ${themeClasses.textPrimary} text-xs`}>Mathematical Verification:</h4>
          <ul className="list-disc pl-4 space-y-1 text-[11px]">
            <li>Original Investment: {result.shares1} shares × ${result.originalPrice.toFixed(2)} = {formatCurrency(result.cost1)}</li>
            <li>Additional Purchase: {result.roundedShares} shares × ${result.currentPrice.toFixed(2)} = {formatCurrency(result.cost2)}</li>
            <li>Weighted Cost: ({formatCurrency(result.cost1)} + {formatCurrency(result.cost2)}) ÷ {result.totalShares} = <strong>${result.newAvgPrice.toFixed(2)} / share</strong></li>
            <li>New Loss: (${result.newAvgPrice.toFixed(2)} - ${result.currentPrice.toFixed(2)}) ÷ ${result.newAvgPrice.toFixed(2)} = <strong>{formatPercent(result.targetLossPercent)}</strong></li>
          </ul>
        </div>
      )}
    </div>
  );
};
