import React, { useEffect } from 'react';
import { X, Keyboard, Command } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface WindowsShortcutsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WindowsShortcutsModal: React.FC<WindowsShortcutsModalProps> = ({ isOpen, onClose }) => {
  const { themeClasses, mode } = useTheme();

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const shortcuts = [
    { key: 'Ctrl + Enter', description: 'Ejecutar cálculo de recuperación' },
    { key: 'Ctrl + S', description: 'Guardar escenario actual en el historial' },
    { key: 'Ctrl + 0', description: 'Reiniciar valores a 0 (nueva acción)' },
    { key: 'Ctrl + K', description: 'Buscar símbolo bursátil (ticker)' },
    { key: 'Ctrl + D', description: 'Alternar modo claro / oscuro' },
    { key: 'Ctrl + 1', description: 'Ir a pestaña Calculadora' },
    { key: 'Ctrl + 2', description: 'Ir a pestaña Historial de operaciones' },
    { key: 'Ctrl + 3', description: 'Ir a pestaña Ajustes del sistema' },
    { key: 'F11', description: 'Alternar pantalla completa de Windows' },
    { key: 'Esc', description: 'Cerrar ventanas y diálogos emergentes' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
      <div
        className={`w-full max-w-md rounded-2xl border ${themeClasses.cardBorder} ${
          mode === 'dark' ? 'bg-slate-900' : 'bg-white'
        } p-5 shadow-2xl transition-all`}
      >
        <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800 mb-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/15 flex items-center justify-center text-emerald-500">
              <Keyboard className="w-4 h-4" />
            </div>
            <div>
              <h3 className={`text-sm font-bold ${themeClasses.textPrimary}`}>
                Atajos de Teclado de Windows
              </h3>
              <p className={`text-[11px] ${themeClasses.textMuted}`}>
                Controla la aplicación de forma rápida y eficiente
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-2 max-h-[60vh] overflow-y-auto pr-1">
          {shortcuts.map((item) => (
            <div
              key={item.key}
              className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700/50 text-xs"
            >
              <span className={`${themeClasses.textSecondary} font-medium`}>
                {item.description}
              </span>
              <kbd className="px-2 py-1 rounded bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-mono text-[11px] font-bold text-slate-700 dark:text-slate-200 shadow-2xs">
                {item.key}
              </kbd>
            </div>
          ))}
        </div>

        <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-xs"
          >
            Entendido
          </button>
        </div>
      </div>
    </div>
  );
};
