import React from 'react';
import { Calculator, History, Settings } from 'lucide-react';
import { ActiveTab } from '../types';
import { useTheme } from '../context/ThemeContext';

interface NavigationProps {
  activeTab: ActiveTab;
  onChangeTab: (tab: ActiveTab) => void;
  historyCount: number;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  onChangeTab,
  historyCount,
}) => {
  const { themeClasses, style } = useTheme();
  const isMaterial = style === 'material';

  return (
    <nav
      id="bottom-navigation"
      aria-label="Main navigation"
      className={`fixed bottom-0 left-0 right-0 z-40 border-t ${themeClasses.navBorder} ${themeClasses.navBg} backdrop-blur-md pb-[env(safe-area-inset-bottom,12px)] pt-2 transition-colors`}
    >
      <div className="mx-auto flex max-w-md items-center justify-around px-4">
        {/* Calculator Tab */}
        <button
          id="tab-calculator"
          onClick={() => onChangeTab('calculator')}
          className={`flex min-h-[48px] flex-1 flex-col items-center justify-center gap-1 rounded-2xl py-1 text-[11px] font-bold transition-all cursor-pointer ${
            activeTab === 'calculator'
              ? themeClasses.accentText
              : `${themeClasses.textMuted} hover:${themeClasses.textSecondary}`
          }`}
        >
          <div
            className={`flex h-8 w-16 items-center justify-center transition-all ${
              isMaterial ? 'rounded-full' : 'rounded-xl'
            } ${
              activeTab === 'calculator'
                ? isMaterial
                  ? 'bg-[#e8def8] dark:bg-[#4a4458] text-[#1d192b] dark:text-[#e8def8] shadow-xs'
                  : `${themeClasses.tagBg} font-bold`
                : 'bg-transparent'
            }`}
          >
            <Calculator className="h-4 w-4" />
          </div>
          <span className="tracking-tight">Calculadora</span>
        </button>

        {/* History Tab */}
        <button
          id="tab-history"
          onClick={() => onChangeTab('history')}
          className={`relative flex min-h-[48px] flex-1 flex-col items-center justify-center gap-1 rounded-2xl py-1 text-[11px] font-bold transition-all cursor-pointer ${
            activeTab === 'history'
              ? themeClasses.accentText
              : `${themeClasses.textMuted} hover:${themeClasses.textSecondary}`
          }`}
        >
          <div
            className={`relative flex h-8 w-16 items-center justify-center transition-all ${
              isMaterial ? 'rounded-full' : 'rounded-xl'
            } ${
              activeTab === 'history'
                ? isMaterial
                  ? 'bg-[#e8def8] dark:bg-[#4a4458] text-[#1d192b] dark:text-[#e8def8] shadow-xs'
                  : `${themeClasses.tagBg} font-bold`
                : 'bg-transparent'
            }`}
          >
            <History className="h-4 w-4" />
            {historyCount > 0 && (
              <span
                className={`absolute -top-1 right-2 flex h-4 min-w-[16px] items-center justify-center rounded-full ${
                  isMaterial
                    ? 'bg-[#b3261e] text-white'
                    : themeClasses.accentBg
                } px-1 text-[9px] font-black shadow-xs`}
              >
                {historyCount}
              </span>
            )}
          </div>
          <span className="tracking-tight">Historial</span>
        </button>

        {/* Settings Tab */}
        <button
          id="tab-settings"
          onClick={() => onChangeTab('settings')}
          className={`flex min-h-[48px] flex-1 flex-col items-center justify-center gap-1 rounded-2xl py-1 text-[11px] font-bold transition-all cursor-pointer ${
            activeTab === 'settings'
              ? themeClasses.accentText
              : `${themeClasses.textMuted} hover:${themeClasses.textSecondary}`
          }`}
        >
          <div
            className={`flex h-8 w-16 items-center justify-center transition-all ${
              isMaterial ? 'rounded-full' : 'rounded-xl'
            } ${
              activeTab === 'settings'
                ? isMaterial
                  ? 'bg-[#e8def8] dark:bg-[#4a4458] text-[#1d192b] dark:text-[#e8def8] shadow-xs'
                  : `${themeClasses.tagBg} font-bold`
                : 'bg-transparent'
            }`}
          >
            <Settings className="h-4 w-4" />
          </div>
          <span className="tracking-tight">Ajustes</span>
        </button>
      </div>
    </nav>
  );
};
