import React from 'react';
import {
  Calculator,
  History,
  Settings,
  PlusCircle,
  FileSpreadsheet,
  Percent,
  BookmarkPlus,
  Check,
  Search,
} from 'lucide-react';
import { ActiveTab } from '../types';
import { useTheme } from '../context/ThemeContext';

interface WindowsCommandBarProps {
  activeTab: ActiveTab;
  onChangeTab: (tab: ActiveTab) => void;
  historyCount: number;
  onReset: () => void;
  onLoadSpreadsheetPreset: () => void;
  onLoadFormulaPreset: () => void;
  onSave: () => void;
  isSaved?: boolean;
  canSave?: boolean;
  onFocusSearch: () => void;
}

export const WindowsCommandBar: React.FC<WindowsCommandBarProps> = ({
  activeTab,
  onChangeTab,
  historyCount,
  onReset,
  onLoadSpreadsheetPreset,
  onLoadFormulaPreset,
  onSave,
  isSaved = false,
  canSave = false,
  onFocusSearch,
}) => {
  const { themeClasses, mode } = useTheme();

  return (
    <div
      id="windows-command-bar"
      className={`border-b ${
        mode === 'dark' ? 'border-slate-800/80 bg-slate-900/60' : 'border-slate-200/80 bg-white/70'
      } backdrop-blur-md px-3 py-1.5 flex items-center justify-between gap-2 overflow-x-auto no-scrollbar z-40 transition-colors`}
    >
      {/* Left: Primary App Navigation Tabs (Windows 11 Tab view) */}
      <div className="flex items-center gap-1 shrink-0">
        <button
          type="button"
          onClick={() => onChangeTab('calculator')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            activeTab === 'calculator'
              ? `${themeClasses.accentBg} shadow-xs`
              : `${themeClasses.textSecondary} hover:${themeClasses.textPrimary} hover:bg-black/5 dark:hover:bg-white/5`
          }`}
        >
          <Calculator className="w-3.5 h-3.5" />
          <span>Calculadora</span>
          <kbd className="hidden lg:inline text-[9px] opacity-60 ml-0.5">Ctrl+1</kbd>
        </button>

        <button
          type="button"
          onClick={() => onChangeTab('history')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            activeTab === 'history'
              ? `${themeClasses.accentBg} shadow-xs`
              : `${themeClasses.textSecondary} hover:${themeClasses.textPrimary} hover:bg-black/5 dark:hover:bg-white/5`
          }`}
        >
          <History className="w-3.5 h-3.5" />
          <span>Historial</span>
          {historyCount > 0 && (
            <span
              className={`text-[10px] font-bold px-1.5 py-0.2 rounded-full ${
                activeTab === 'history' ? 'bg-black/20 text-white' : 'bg-emerald-500/20 text-emerald-500'
              }`}
            >
              {historyCount}
            </span>
          )}
          <kbd className="hidden lg:inline text-[9px] opacity-60 ml-0.5">Ctrl+2</kbd>
        </button>

        <button
          type="button"
          onClick={() => onChangeTab('settings')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            activeTab === 'settings'
              ? `${themeClasses.accentBg} shadow-xs`
              : `${themeClasses.textSecondary} hover:${themeClasses.textPrimary} hover:bg-black/5 dark:hover:bg-white/5`
          }`}
        >
          <Settings className="w-3.5 h-3.5" />
          <span>Ajustes</span>
          <kbd className="hidden lg:inline text-[9px] opacity-60 ml-0.5">Ctrl+3</kbd>
        </button>
      </div>

      {/* Right: Windows 11 Command Actions Toolbar */}
      <div className="flex items-center gap-1 shrink-0">
        {/* Quick Ticker Search trigger */}
        <button
          type="button"
          onClick={onFocusSearch}
          title="Buscar símbolo bursátil (Ctrl+K)"
          className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium border ${themeClasses.cardBorder} ${themeClasses.cardBg} ${themeClasses.textSecondary} hover:${themeClasses.textPrimary} transition-all shadow-2xs`}
        >
          <Search className="w-3 h-3 text-emerald-500" />
          <span className="hidden sm:inline">Buscar Ticker</span>
          <kbd className="hidden md:inline text-[9px] bg-black/5 dark:bg-white/10 px-1 py-0.2 rounded text-slate-500 font-mono">
            Ctrl+K
          </kbd>
        </button>

        {/* New / Reset */}
        <button
          type="button"
          onClick={onReset}
          title="Nueva posición a cero (Ctrl+0)"
          className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium border ${themeClasses.cardBorder} ${themeClasses.cardBg} text-rose-500 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-500/10 transition-all shadow-2xs`}
        >
          <PlusCircle className="w-3 h-3" />
          <span className="hidden sm:inline">Nuevo</span>
          <kbd className="hidden md:inline text-[9px] bg-rose-500/10 px-1 py-0.2 rounded font-mono">
            Ctrl+0
          </kbd>
        </button>

        {/* Presets Dropdown */}
        <div className="relative group">
          <button
            type="button"
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium border ${themeClasses.cardBorder} ${themeClasses.cardBg} ${themeClasses.textSecondary} hover:${themeClasses.textPrimary} transition-all shadow-2xs`}
          >
            <FileSpreadsheet className="w-3 h-3 text-sky-500" />
            <span className="hidden sm:inline">Ejemplos</span>
          </button>
          <div
            className={`absolute right-0 top-full mt-1 hidden w-56 rounded-xl border ${themeClasses.cardBorder} ${themeClasses.cardBg} p-1.5 shadow-2xl group-hover:block z-50 transition-all`}
          >
            <p className={`px-2 py-1 text-[10px] font-bold uppercase tracking-wider ${themeClasses.textMuted}`}>
              Plantillas Rápidas
            </p>
            <button
              type="button"
              onClick={onLoadSpreadsheetPreset}
              className={`w-full text-left px-2.5 py-1.5 text-xs font-medium ${themeClasses.textPrimary} hover:${themeClasses.tagBg} rounded-md transition flex items-center gap-2`}
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-sky-500" />
              <span>Ejemplo Excel (234 acc)</span>
            </button>
            <button
              type="button"
              onClick={onLoadFormulaPreset}
              className={`w-full text-left px-2.5 py-1.5 text-xs font-medium ${themeClasses.textPrimary} hover:${themeClasses.tagBg} rounded-md transition flex items-center gap-2`}
            >
              <Percent className="w-3.5 h-3.5 text-emerald-500" />
              <span>Estándar 2% (180 acc)</span>
            </button>
          </div>
        </div>

        {/* Save Scenario Button */}
        {canSave && (
          <button
            type="button"
            onClick={onSave}
            title="Guardar en historial (Ctrl+S)"
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all shadow-2xs ${
              isSaved
                ? 'bg-emerald-500/20 text-emerald-500 border border-emerald-500/30'
                : 'bg-emerald-600 hover:bg-emerald-700 text-white'
            }`}
          >
            {isSaved ? (
              <>
                <Check className="w-3 h-3" />
                <span className="hidden sm:inline">Guardado</span>
              </>
            ) : (
              <>
                <BookmarkPlus className="w-3 h-3" />
                <span>Guardar</span>
                <kbd className="hidden md:inline text-[9px] bg-white/20 px-1 py-0.2 rounded font-mono">
                  Ctrl+S
                </kbd>
              </>
            )}
          </button>
        )}
      </div>
    </div>
  );
};
