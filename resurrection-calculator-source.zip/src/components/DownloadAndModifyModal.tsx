import React, { useState, useEffect } from 'react';
import {
  X,
  Laptop,
  Smartphone,
  Download,
  CheckCircle,
  Copy,
  ExternalLink,
  Code2,
  Sparkles,
  Github,
  QrCode,
  Share2,
  Terminal,
  Layers,
  ArrowRight,
  Square,
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

interface DownloadAndModifyModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultTab?: 'download' | 'modify';
}

export const DownloadAndModifyModal: React.FC<DownloadAndModifyModalProps> = ({
  isOpen,
  onClose,
  defaultTab = 'download',
}) => {
  const { themeClasses, mode, style } = useTheme();
  const [activeTab, setActiveTab] = useState<'download' | 'modify'>(defaultTab);
  const [installOS, setInstallOS] = useState<'windows' | 'android'>('windows');
  const [copied, setCopied] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [showQR, setShowQR] = useState(false);

  // App URLs
  const appUrl = typeof window !== 'undefined' ? window.location.href.split('#')[0] : 'https://ais-dev-aguo3z3mjrl7jfh7nusgs7-392670282288.us-east1.run.app';
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(appUrl)}&margin=8`;

  useEffect(() => {
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true);
    }

    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    window.addEventListener('beforeinstallprompt', handler);
    window.addEventListener('appinstalled', () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    });

    return () => {
      window.removeEventListener('beforeinstallprompt', handler);
    };
  }, []);

  if (!isOpen) return null;

  const handleCopyLink = async () => {
    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(appUrl);
      } else {
        const input = document.createElement('input');
        input.value = appUrl;
        document.body.appendChild(input);
        input.select();
        document.execCommand('copy');
        document.body.removeChild(input);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // fallback
    }
  };

  const handleNativeInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setIsInstalled(true);
        setDeferredPrompt(null);
      }
    }
  };

  const isMaterial = style === 'material';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div
        className={`w-full max-w-xl rounded-2xl border ${themeClasses.cardBorder} ${
          mode === 'dark' ? 'bg-slate-900 text-slate-100' : 'bg-white text-slate-900'
        } shadow-2xl transition-all my-auto max-h-[92vh] flex flex-col`}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div
              className={`w-9 h-9 rounded-xl ${
                isMaterial ? 'bg-[#6750a4] text-white' : 'bg-emerald-600 text-white'
              } flex items-center justify-center shadow-xs`}
            >
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold tracking-tight">
                Descargar, Instalar y Modificar App
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Acceso multiplataforma y opciones para personalizar el código
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Top Navigation Tabs inside Modal */}
        <div className="flex items-center border-b border-slate-200 dark:border-slate-800 px-4 sm:px-5 pt-2 shrink-0 bg-slate-50/50 dark:bg-slate-950/30">
          <button
            type="button"
            onClick={() => setActiveTab('download')}
            className={`flex items-center gap-2 py-2.5 px-4 text-xs font-bold border-b-2 transition-all cursor-pointer ${
              activeTab === 'download'
                ? isMaterial
                  ? 'border-[#6750a4] text-[#6750a4] dark:text-[#d0bcff]'
                  : 'border-emerald-500 text-emerald-600 dark:text-emerald-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Download className="w-4 h-4" />
            <span>1. Descargar / Instalar</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('modify')}
            className={`flex items-center gap-2 py-2.5 px-4 text-xs font-bold border-b-2 transition-all cursor-pointer ${
              activeTab === 'modify'
                ? isMaterial
                  ? 'border-[#6750a4] text-[#6750a4] dark:text-[#d0bcff]'
                  : 'border-emerald-500 text-emerald-600 dark:text-emerald-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Code2 className="w-4 h-4" />
            <span>2. Cómo Modificar la App</span>
          </button>
        </div>

        {/* Modal Scrollable Content */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
          {activeTab === 'download' ? (
            <div className="space-y-4">
              {/* Direct Link & Copy Widget */}
              <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/50 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300">
                    Enlace directo de la aplicación:
                  </span>
                  <button
                    type="button"
                    onClick={() => setShowQR(!showQR)}
                    className="text-[10px] font-semibold text-sky-600 dark:text-sky-400 hover:underline flex items-center gap-1"
                  >
                    <QrCode className="w-3 h-3" />
                    <span>{showQR ? 'Ocultar QR' : 'Ver Código QR'}</span>
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={appUrl}
                    className="flex-1 text-[11px] font-mono px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 truncate focus:outline-hidden"
                  />
                  <button
                    type="button"
                    onClick={handleCopyLink}
                    className={`px-3.5 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all shrink-0 ${
                      copied
                        ? 'bg-emerald-600 text-white'
                        : isMaterial
                        ? 'bg-[#6750a4] hover:bg-[#5a4392] text-white'
                        : 'bg-slate-800 hover:bg-slate-700 dark:bg-slate-700 dark:hover:bg-slate-600 text-white'
                    }`}
                  >
                    {copied ? (
                      <>
                        <CheckCircle className="w-3.5 h-3.5" />
                        <span>¡Copiado!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copiar Enlace</span>
                      </>
                    )}
                  </button>
                  <a
                    href={appUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="p-2 rounded-lg border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 shrink-0"
                    title="Abrir en pestaña nueva"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>

                {/* QR Code Container for phone camera scan */}
                {showQR && (
                  <div className="pt-2 flex flex-col items-center justify-center p-4 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 text-center space-y-2">
                    <img
                      src={qrCodeUrl}
                      alt="Código QR de la aplicación"
                      className="w-40 h-40 rounded-lg shadow-xs"
                    />
                    <p className="text-[11px] text-slate-600 dark:text-slate-400 max-w-xs">
                      Escanea este código con la cámara de tu <b>móvil Android</b> o <b>iPhone</b> para abrir e instalar la app al instante.
                    </p>
                  </div>
                )}
              </div>

              {/* OS Selector Tabs */}
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setInstallOS('windows')}
                  className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                    installOS === 'windows'
                      ? 'border-sky-500 bg-sky-500/10 text-sky-600 dark:text-sky-400 ring-1 ring-sky-500/30'
                      : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100/50 dark:hover:bg-slate-800/50'
                  }`}
                >
                  <Laptop className="w-4 h-4" />
                  <span>En Windows 11 (PC)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setInstallOS('android')}
                  className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                    installOS === 'android'
                      ? 'border-purple-500 bg-purple-500/10 text-purple-600 dark:text-purple-400 ring-1 ring-purple-500/30'
                      : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100/50 dark:hover:bg-slate-800/50'
                  }`}
                >
                  <Smartphone className="w-4 h-4" />
                  <span>En Android (APK / PWA)</span>
                </button>
              </div>

              {/* Specific Guide according to OS */}
              {installOS === 'windows' ? (
                <div className="space-y-3">
                  {deferredPrompt && (
                    <button
                      type="button"
                      onClick={handleNativeInstall}
                      className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition"
                    >
                      <Download className="w-4 h-4" />
                      <span>Instalar en Windows en 1 Clic</span>
                    </button>
                  )}

                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/60 space-y-2 text-xs">
                    <p className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                      <Laptop className="w-4 h-4 text-sky-500" />
                      <span>Pasos para instalar en tu PC con Windows 11:</span>
                    </p>
                    <ol className="list-decimal list-inside space-y-1.5 text-slate-600 dark:text-slate-400 text-[11px] leading-relaxed">
                      <li>Abre el enlace en <b>Microsoft Edge</b> o <b>Google Chrome</b> en tu ordenador.</li>
                      <li>
                        En la barra de direcciones (arriba a la derecha), haz clic en el icono <b>"Instalar aplicación"</b> o <b>"+"</b>.
                      </li>
                      <li>
                        Pulsa <b>"Instalar"</b>. Windows creará automáticamente el acceso directo en tu <b>Escritorio</b> y en el menú <b>Inicio</b>.
                      </li>
                      <li>
                        Se abrirá en su propia ventana nativa independiente y funcionará al 100% sin conexión a internet.
                      </li>
                    </ol>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  {/* Android Notice */}
                  <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/25 space-y-2 text-xs">
                    <p className="font-bold text-amber-900 dark:text-amber-300 flex items-center gap-1.5">
                      <Smartphone className="w-4 h-4 text-amber-500" />
                      <span>¿Por qué en Android se abre dentro del navegador?</span>
                    </p>
                    <p className="text-[11px] text-slate-700 dark:text-slate-300 leading-relaxed">
                      El entorno de desarrollo de <b>Google AI Studio</b> cuenta con una pantalla de seguridad intermedia (comprobación de cookies de Google). Cuando Android detecta esa redirección de seguridad, <b>Chrome fuerza la apertura de una pestaña estándar de navegación</b> en vez de una ventana aislada.
                    </p>
                    <div className="pt-1 flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          if (!document.fullscreenElement) {
                            document.documentElement.requestFullscreen?.().catch(() => {});
                          } else {
                            document.exitFullscreen?.().catch(() => {});
                          }
                        }}
                        className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] flex items-center gap-1.5 transition cursor-pointer"
                      >
                        <Square className="w-3.5 h-3.5" />
                        <span>Activar Modo App Pantalla Completa (Oculta el Navegador)</span>
                      </button>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-xl bg-purple-50 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-800/40 space-y-2 text-xs">
                    <p className="font-bold text-purple-900 dark:text-purple-300 flex items-center gap-1.5">
                      <Layers className="w-4 h-4 text-purple-500" />
                      <span>Solución Recomendada en Android: Hermit (Lite Apps)</span>
                    </p>
                    <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
                      Si quieres un icono en tu pantalla de inicio que <b>NUNCA abra Chrome</b> y se comporte como una app nativa de Android aislada:
                    </p>
                    <ol className="list-decimal list-inside space-y-1 text-[11px] text-slate-600 dark:text-slate-400">
                      <li>Descarga la app gratuita <b>Hermit</b> (Lite Apps Browser) desde Google Play Store.</li>
                      <li>Pega el enlace de tu app y pulsa "Crear Lite App".</li>
                      <li>Hermit creará el icono en tu pantalla y lo abrirá en su propio contenedor nativo sin Chrome.</li>
                    </ol>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/60 space-y-2 text-xs">
                    <p className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                      <Layers className="w-4 h-4 text-emerald-500" />
                      <span>Opción B: Generar un archivo instalable .APK con PWABuilder</span>
                    </p>
                    <div className="p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-800 dark:text-amber-300 text-[11px] leading-relaxed">
                      <b>¿Te sale "Missing Name / Create a web app manifest" en PWABuilder?</b><br />
                      Esto ocurre porque los servidores externos de PWABuilder no pueden atravesar la pantalla de seguridad de Google AI Studio (302 cookie check). En cambio, <b>la Opción A directa en Chrome sí funciona al 100%</b> porque tu móvil ya está autorizado.
                    </div>
                    <p className="text-[11px] text-slate-600 dark:text-slate-400">
                      Si aún así quieres usar PWABuilder para generar un paquete APK, puedes copiar el código del Manifest y pegarlo en su editor:
                    </p>
                    <div className="flex flex-wrap items-center gap-2 pt-1">
                      <button
                        type="button"
                        onClick={async () => {
                          const manifestText = JSON.stringify({
                            id: "/",
                            name: "Resurrection Calculator",
                            short_name: "Resurrection",
                            description: "Trading position recovery and averaging-down calculator to reduce loss to target percentage.",
                            start_url: "/",
                            scope: "/",
                            display: "standalone",
                            theme_color: "#059669",
                            background_color: "#0f172a",
                            icons: [
                              { src: "/pwa-192x192.png", sizes: "192x192", type: "image/png", purpose: "any" },
                              { src: "/pwa-512x512.png", sizes: "512x512", type: "image/png", purpose: "any" },
                              { src: "/pwa-maskable-512x512.png", sizes: "512x512", type: "image/png", purpose: "maskable" }
                            ]
                          }, null, 2);
                          await navigator.clipboard.writeText(manifestText);
                          alert("¡Código del Manifest copiado al portapapeles!");
                        }}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-700 hover:bg-slate-800 text-white text-[11px] font-bold transition cursor-pointer"
                      >
                        <Copy className="w-3 h-3" />
                        <span>Copiar Código Manifest (JSON)</span>
                      </button>
                      <a
                        href={`https://www.pwabuilder.com/?site=${encodeURIComponent(appUrl)}`}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold transition"
                      >
                        <span>Abrir PWABuilder</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ) : (
            /* WAYS TO MODIFY THE APPLICATION */
            <div className="space-y-3.5 text-xs">
              {/* Method 1: Conversational AI in Studio */}
              <div className="p-3.5 rounded-xl border border-emerald-500/30 bg-emerald-500/5 dark:bg-emerald-950/20 space-y-1.5">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-md bg-emerald-500 text-white flex items-center justify-center shrink-0">
                    <Sparkles className="w-3.5 h-3.5" />
                  </div>
                  <h4 className="font-bold text-emerald-700 dark:text-emerald-300">
                    Vía 1: Modificar a través del Chat de IA (Inmediata y Sin Código)
                  </h4>
                </div>
                <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
                  No necesitas programar nada a mano. Simplemente <b>escríbeme aquí en el chat</b> lo que quieres añadir o cambiar.
                </p>
                <div className="p-2 rounded-lg bg-white/80 dark:bg-slate-900/80 border border-emerald-500/20 text-[11px] font-medium text-slate-700 dark:text-slate-300 space-y-1">
                  <p className="font-bold text-emerald-600 dark:text-emerald-400">Ejemplos de lo que puedes pedirme:</p>
                  <p className="italic">«Añade una calculadora de dividendos»</p>
                  <p className="italic">«Cambia la fórmula para que soporte apalancamiento»</p>
                  <p className="italic">«Agrega una alerta sonora cuando el cálculo termine»</p>
                </div>
              </div>

              {/* Method 2: Export Code to GitHub or ZIP */}
              <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/40 space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-md bg-slate-800 text-white flex items-center justify-center shrink-0">
                    <Github className="w-3.5 h-3.5" />
                  </div>
                  <h4 className="font-bold text-slate-800 dark:text-slate-200">
                    Vía 2: Exportar el Código a tu Computadora (GitHub o Archivo ZIP)
                  </h4>
                </div>
                <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
                  Puedes descargar todos los archivos del proyecto a tu ordenador para editarlos en <b>Visual Studio Code</b>:
                </p>
                <ol className="list-decimal list-inside space-y-1 text-[11px] text-slate-600 dark:text-slate-400">
                  <li>En la esquina superior derecha de la interfaz de <b>Google AI Studio</b>, abre el menú de opciones (o Ajustes).</li>
                  <li>Selecciona <b>"Export to GitHub"</b> o <b>"Download as ZIP"</b>.</li>
                </ol>
                <div className="pt-1">
                  <a
                    href="/download-zip"
                    download="resurrection-calculator-source.zip"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold transition shadow-xs"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Descargar código completo en ZIP</span>
                  </a>
                </div>
                <div className="p-2.5 rounded-lg bg-slate-900 text-slate-200 font-mono text-[10px] space-y-1">
                  <p className="text-slate-400">// Para ejecutarlo en tu computadora:</p>
                  <p><span className="text-emerald-400">$</span> npm install</p>
                  <p><span className="text-emerald-400">$</span> npm run dev</p>
                </div>
                <p className="text-[10px] text-slate-500 dark:text-slate-400">
                  El código está construido con React 18, TypeScript y Tailwind CSS en <code className="font-mono text-sky-600 dark:text-sky-400">/src/utils/calculator.ts</code>.
                </p>
              </div>

              {/* Method 3: In-App Settings Customization */}
              <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/40 space-y-1.5">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-md bg-sky-500 text-white flex items-center justify-center shrink-0">
                    <Terminal className="w-3.5 h-3.5" />
                  </div>
                  <h4 className="font-bold text-slate-800 dark:text-slate-200">
                    Vía 3: Personalizar desde la pestaña Ajustes
                  </h4>
                </div>
                <p className="text-[11px] text-slate-600 dark:text-slate-400">
                  En la pestaña <b>Ajustes</b> puedes cambiar en tiempo real los temas (Material Android, Windows 11 Fluent, Terminal Pro, Cyberpunk) y gestionar el historial sin tocar código.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0 bg-slate-50/30 dark:bg-slate-950/20">
          <button
            type="button"
            onClick={handleCopyLink}
            className="text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 flex items-center gap-1 cursor-pointer"
          >
            <Copy className="w-3.5 h-3.5" />
            <span>{copied ? '¡Enlace copiado!' : 'Copiar URL'}</span>
          </button>
          <button
            type="button"
            onClick={onClose}
            className={`px-4 py-2 rounded-xl ${
              isMaterial ? 'bg-[#6750a4] text-white hover:bg-[#5a4392]' : 'bg-slate-800 dark:bg-slate-700 text-white hover:bg-slate-700'
            } text-xs font-bold transition cursor-pointer`}
          >
            Entendido
          </button>
        </div>
      </div>
    </div>
  );
};
