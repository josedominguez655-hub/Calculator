import React, { useState, useEffect } from 'react';
import { X, Laptop, Download, CheckCircle, ArrowRight, ShieldCheck } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

interface WindowsInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WindowsInstallModal: React.FC<WindowsInstallModalProps> = ({ isOpen, onClose }) => {
  const { themeClasses, mode } = useTheme();
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);

  useEffect(() => {
    // Check if already in standalone mode
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true);
    }

    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    window.addEventListener('beforeinstallprompt', handler);
    window.addEventListener('appinstalled', () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    });

    return () => {
      window.removeEventListener('beforeinstallprompt', handler);
    };
  }, []);

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setIsInstalled(true);
        setDeferredPrompt(null);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
      <div
        className={`w-full max-w-md rounded-2xl border ${themeClasses.cardBorder} ${
          mode === 'dark' ? 'bg-slate-900' : 'bg-white'
        } p-5 shadow-2xl transition-all`}
      >
        <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800 mb-4">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-sky-500/15 flex items-center justify-center text-sky-500">
              <Laptop className="w-5 h-5" />
            </div>
            <div>
              <h3 className={`text-sm font-bold ${themeClasses.textPrimary}`}>
                Instalar en Windows 11
              </h3>
              <p className={`text-[11px] ${themeClasses.textMuted}`}>
                Acceso directo desde tu Escritorio y menú de Inicio
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {isInstalled ? (
          <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-center space-y-2">
            <CheckCircle className="w-8 h-8 text-emerald-500 mx-auto" />
            <p className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
              ¡La aplicación ya está instalada en tu equipo!
            </p>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Puedes abrirla en cualquier momento desde el menú Inicio o tu Escritorio de Windows 11. Funciona 100% offline.
            </p>
          </div>
        ) : (
          <div className="space-y-3 text-xs">
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700/50 space-y-2">
              <div className="flex items-center gap-2 font-bold text-slate-800 dark:text-slate-200">
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
                <span>Ventajas de instalarla en Windows:</span>
              </div>
              <ul className="list-disc list-inside space-y-1 text-slate-600 dark:text-slate-400 text-[11px]">
                <li>Se abre en su propia ventana nativa sin barra de navegador.</li>
                <li>Icono permanente en el <b>Escritorio</b> y menú <b>Inicio</b>.</li>
                <li>Funciona sin internet (cálculos locales y caché offline).</li>
                <li>Cero archivos que descomprimir ni configuraciones complicadas.</li>
              </ul>
            </div>

            {deferredPrompt && (
              <button
                type="button"
                onClick={handleInstallClick}
                className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center justify-center gap-2 shadow-sm transition"
              >
                <Download className="w-4 h-4" />
                <span>Instalar Ahora en 1 Clic</span>
              </button>
            )}

            <div className="p-3 rounded-xl bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800/40 space-y-1.5 text-[11px]">
              <p className="font-bold text-sky-800 dark:text-sky-300">
                O desde Microsoft Edge / Google Chrome:
              </p>
              <p className="text-slate-600 dark:text-slate-400">
                1. Mira la barra de direcciones de tu navegador (arriba a la derecha).
              </p>
              <p className="text-slate-600 dark:text-slate-400">
                2. Haz clic en el icono <b>"Instalar aplicación"</b> o <b>"+"</b>.
              </p>
              <p className="text-slate-600 dark:text-slate-400">
                3. Pulsa en <b>"Instalar"</b> y listo. Windows creará tu acceso directo.
              </p>
            </div>
          </div>
        )}

        <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-semibold transition"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
