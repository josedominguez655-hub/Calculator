import React, { useState } from 'react';
import {
  BookOpen,
  ShieldCheck,
  CheckCircle2,
  RotateCcw,
  Download,
  Copy,
  CheckCircle,
  ExternalLink,
  QrCode,
  Laptop,
  Smartphone,
  Code2,
  Sparkles,
  Github,
  Layers,
} from 'lucide-react';
import { ThemeSelector } from './ThemeSelector';
import { useTheme } from '../context/ThemeContext';

interface SettingsViewProps {
  onResetAll: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ onResetAll }) => {
  const { themeClasses, style } = useTheme();
  const [copied, setCopied] = useState(false);
  const [showQR, setShowQR] = useState(false);

  const appUrl = typeof window !== 'undefined' ? window.location.href.split('#')[0] : 'https://ais-dev-aguo3z3mjrl7jfh7nusgs7-392670282288.us-east1.run.app';
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(appUrl)}&margin=8`;

  const handleCopyLink = async () => {
    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(appUrl);
      } else {
        const input = document.createElement('input');
        input.value = appUrl;
        document.body.appendChild(input);
        input.select();
        document.execCommand('copy');
        document.body.removeChild(input);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // fallback
    }
  };

  const isMaterial = style === 'material';

  return (
    <div className="space-y-4">
      {/* 1. DIRECT DOWNLOAD & INSTALL CARD */}
      <div className={`rounded-2xl border ${themeClasses.cardBorder} ${themeClasses.cardBg} p-4 sm:p-5 shadow-xs transition-colors`}>
        <div className={`flex items-center justify-between pb-3 border-b ${themeClasses.divider} mb-3.5`}>
          <div className="flex items-center gap-2">
            <Download className={`h-4 w-4 ${themeClasses.accentText}`} />
            <h3 className={`text-sm font-bold ${themeClasses.textPrimary}`}>
              Descargar e Instalar la Aplicación
            </h3>
          </div>
          <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${themeClasses.tagBg}`}>
            Windows 11 & Android
          </span>
        </div>

        <div className="space-y-3 text-xs">
          <p className={themeClasses.textSecondary}>
            Puedes instalar y ejecutar esta aplicación de manera independiente como una app nativa en tu <b>computadora con Windows 11</b> o en tu <b>móvil Android</b>:
          </p>

          {/* Link Copy Box */}
          <div className={`p-3 rounded-xl border ${themeClasses.cardBorder} ${themeClasses.inputBg} space-y-2`}>
            <div className="flex items-center justify-between">
              <span className={`text-[11px] font-bold ${themeClasses.textPrimary}`}>
                Enlace directo para abrir o compartir:
              </span>
              <button
                type="button"
                onClick={() => setShowQR(!showQR)}
                className={`text-[11px] font-semibold text-sky-600 dark:text-sky-400 hover:underline flex items-center gap-1 cursor-pointer`}
              >
                <QrCode className="w-3.5 h-3.5" />
                <span>{showQR ? 'Ocultar código QR' : 'Ver código QR'}</span>
              </button>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={appUrl}
                className={`flex-1 text-[11px] font-mono px-3 py-2 rounded-lg border ${themeClasses.inputBorder} ${themeClasses.inputBg} ${themeClasses.inputText} truncate focus:outline-hidden`}
              />
              <button
                type="button"
                onClick={handleCopyLink}
                className={`px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all shrink-0 cursor-pointer ${
                  copied
                    ? 'bg-emerald-600 text-white'
                    : isMaterial
                    ? 'bg-[#6750a4] hover:bg-[#5a4392] text-white'
                    : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                }`}
              >
                {copied ? (
                  <>
                    <CheckCircle className="w-3.5 h-3.5" />
                    <span>¡Copiado!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copiar Enlace</span>
                  </>
                )}
              </button>
              <a
                href={appUrl}
                target="_blank"
                rel="noreferrer"
                className={`p-2 rounded-lg border ${themeClasses.cardBorder} hover:bg-black/5 dark:hover:bg-white/5 ${themeClasses.textSecondary} shrink-0`}
                title="Abrir en nueva pestaña"
              >
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>

            {/* QR Code Container */}
            {showQR && (
              <div className="pt-2 flex flex-col items-center justify-center p-3.5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 text-center space-y-2">
                <img
                  src={qrCodeUrl}
                  alt="Código QR de la aplicación"
                  className="w-36 h-36 rounded-lg shadow-xs"
                />
                <p className="text-[11px] text-slate-600 dark:text-slate-400 max-w-xs">
                  Escanea con la cámara de tu teléfono móvil para abrir la app directamente en Android o iOS.
                </p>
              </div>
            )}
          </div>

          {/* Quick Installation Instructions */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
            <div className={`p-3 rounded-xl border ${themeClasses.cardBorder} ${themeClasses.tagBg} space-y-1.5`}>
              <div className="flex items-center gap-1.5 font-bold">
                <Laptop className="w-4 h-4 text-sky-500" />
                <span className={themeClasses.textPrimary}>Para Windows 11:</span>
              </div>
              <p className={`text-[11px] ${themeClasses.textSecondary} leading-relaxed`}>
                Abre el enlace en <b>Edge</b> o <b>Chrome</b> y haz clic en el icono <b>"Instalar"</b> en la barra de direcciones o en el botón verde superior. Se creará el acceso directo en tu Escritorio.
              </p>
            </div>

            <div className={`p-3 rounded-xl border ${themeClasses.cardBorder} ${themeClasses.tagBg} space-y-1.5`}>
              <div className="flex items-center gap-1.5 font-bold">
                <Smartphone className="w-4 h-4 text-purple-500" />
                <span className={themeClasses.textPrimary}>Para Android (APK / PWA):</span>
              </div>
              <p className={`text-[11px] ${themeClasses.textSecondary} leading-relaxed`}>
                Abre el enlace en <b>Chrome para Android</b>, toca el menú de tres puntos (<b>⋮</b>) y selecciona <b>"Instalar aplicación"</b> o <b>"Añadir a pantalla de inicio"</b>.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 2. HOW TO MODIFY THIS APPLICATION CARD */}
      <div className={`rounded-2xl border ${themeClasses.cardBorder} ${themeClasses.cardBg} p-4 sm:p-5 shadow-xs transition-colors`}>
        <div className={`flex items-center justify-between pb-3 border-b ${themeClasses.divider} mb-3.5`}>
          <div className="flex items-center gap-2">
            <Code2 className={`h-4 w-4 ${themeClasses.accentText}`} />
            <h3 className={`text-sm font-bold ${themeClasses.textPrimary}`}>
              Opciones para Modificar esta Aplicación
            </h3>
          </div>
          <span className={`text-[11px] font-bold text-emerald-600 dark:text-emerald-400`}>
            3 Vías de Desarrollo
          </span>
        </div>

        <div className="space-y-3 text-xs leading-relaxed">
          {/* Method A: Conversational AI in Studio */}
          <div className={`p-3.5 rounded-xl border border-emerald-500/30 bg-emerald-500/5 dark:bg-emerald-950/20 space-y-1.5`}>
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 rounded bg-emerald-500 text-white flex items-center justify-center shrink-0">
                <Sparkles className="w-3 h-3" />
              </div>
              <h4 className="font-bold text-emerald-700 dark:text-emerald-300">
                Vía 1: Modificar a través del Chat de IA (Inmediata y Sin Código)
              </h4>
            </div>
            <p className={`${themeClasses.textSecondary} text-[11px]`}>
              La forma más rápida y potente. Simplemente <b>pídeme en lenguaje natural</b> cualquier cambio aquí en el chat de Google AI Studio. Yo escribiré el código, lo compilaré y actualizaré la aplicación en segundos.
            </p>
            <div className="p-2 rounded-lg bg-white/70 dark:bg-slate-900/70 border border-emerald-500/20 text-[11px] text-slate-700 dark:text-slate-300">
              <span className="font-bold text-emerald-600 dark:text-emerald-400">Ejemplo:</span> «Añade una pestaña con alertas de precio» o «Cambia los colores de la fórmula».
            </div>
          </div>

          {/* Method B: Export to GitHub / ZIP */}
          <div className={`p-3.5 rounded-xl border ${themeClasses.cardBorder} ${themeClasses.tagBg} space-y-1.5`}>
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 rounded bg-slate-800 text-white flex items-center justify-center shrink-0">
                <Github className="w-3 h-3" />
              </div>
              <h4 className={`font-bold ${themeClasses.textPrimary}`}>
                Vía 2: Exportar el Código Fuente (GitHub o Archivo ZIP)
              </h4>
            </div>
            <p className={`${themeClasses.textSecondary} text-[11px]`}>
              Si deseas programar tú mismo o alojar el código en tu propio servidor:
            </p>
            <ol className="list-decimal list-inside space-y-1 text-[11px] text-slate-600 dark:text-slate-400">
              <li>En la barra superior de <b>Google AI Studio</b>, abre el menú de opciones (⚙️ o menú de tres puntos).</li>
              <li>Elige <b>"Export to GitHub"</b> para crear un repositorio, o <b>"Download ZIP"</b> para bajar todos los archivos a tu PC.</li>
              <li>Ábrelo en <b>Visual Studio Code</b> y ejecuta <code className="font-mono text-emerald-600 dark:text-emerald-400">npm install && npm run dev</code>.</li>
            </ol>
          </div>

          {/* Method C: PWABuilder to compile APK */}
          <div className={`p-3.5 rounded-xl border ${themeClasses.cardBorder} ${themeClasses.tagBg} space-y-1.5`}>
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 rounded bg-purple-600 text-white flex items-center justify-center shrink-0">
                <Layers className="w-3 h-3" />
              </div>
              <h4 className={`font-bold ${themeClasses.textPrimary}`}>
                Vía 3: Convertir a APK nativo para Android (PWABuilder)
              </h4>
            </div>
            <p className={`${themeClasses.textSecondary} text-[11px]`}>
              Para generar un paquete <b>.apk</b> que puedas instalar en cualquier Android o subir a Google Play Store:
            </p>
            <div className="pt-1">
              <a
                href={`https://www.pwabuilder.com/?site=${encodeURIComponent(appUrl)}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-700 text-white text-[11px] font-bold transition"
              >
                <span>Abrir PWABuilder con este proyecto</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* 3. VISUAL THEMES & LIGHT / DARK SELECTOR */}
      <ThemeSelector variant="card" />

      {/* 4. ABOUT THE RESURRECTION FORMULA */}
      <div className={`rounded-2xl border ${themeClasses.cardBorder} ${themeClasses.cardBg} p-4 sm:p-5 shadow-xs transition-colors`}>
        <div className={`flex items-center gap-2 pb-2.5 border-b ${themeClasses.divider} mb-3`}>
          <BookOpen className={`h-4 w-4 ${themeClasses.accentText}`} />
          <h3 className={`text-sm font-bold ${themeClasses.textPrimary}`}>About the System</h3>
        </div>

        <div className={`space-y-3 text-xs ${themeClasses.textSecondary} leading-relaxed`}>
          <p>
            The <strong>Resurrection Calculator</strong> is an algorithmic position management system designed to systematically lower the average entry price of a losing stock trade down to a calibrated threshold.
          </p>
          <div className={`rounded-xl ${themeClasses.tagBg} p-3 border ${themeClasses.cardBorder} space-y-1.5 font-mono text-[11px] ${themeClasses.textPrimary}`}>
            <p className="font-bold">Core Equation:</p>
            <p className={themeClasses.accentText}>
              Shares 2 = (Shares 1 × Reduction) / ((1 - Loss/100) × (Loss - Reduction))
            </p>
          </div>
          <p className={`text-[11px] ${themeClasses.textMuted}`}>
            Unlike arbitrary martingale averaging down, this formula ensures you buy only the mathematical minimum number of shares required to dilute your break-even price to your exact target loss.
          </p>
        </div>
      </div>

      {/* 5. DEVICE & OFFLINE COMPLIANCE */}
      <div className={`rounded-2xl border ${themeClasses.cardBorder} ${themeClasses.cardBg} p-4 shadow-xs transition-colors`}>
        <div className={`flex items-center gap-2 pb-2.5 border-b ${themeClasses.divider} mb-3`}>
          <ShieldCheck className={`h-4 w-4 ${themeClasses.accentText}`} />
          <h3 className={`text-sm font-bold ${themeClasses.textPrimary}`}>Mobile & Device Status</h3>
        </div>

        <div className={`space-y-2 text-xs ${themeClasses.textSecondary}`}>
          <div className={`flex items-center justify-between py-1 border-b ${themeClasses.divider}`}>
            <span className={themeClasses.textMuted}>Target Devices:</span>
            <span className={`font-semibold ${themeClasses.textPrimary}`}>Android, Windows 11, iOS, Linux, Mac</span>
          </div>
          <div className={`flex items-center justify-between py-1 border-b ${themeClasses.divider}`}>
            <span className={themeClasses.textMuted}>Offline Functionality:</span>
            <span className={`font-semibold ${themeClasses.accentText} flex items-center gap-1`}>
              <CheckCircle2 className="w-3.5 h-3.5" /> 100% Client-Side
            </span>
          </div>
          <div className={`flex items-center justify-between py-1 border-b ${themeClasses.divider}`}>
            <span className={themeClasses.textMuted}>App Version:</span>
            <span className="font-mono">v2.8 (Win11 + Material Android)</span>
          </div>
          <div className={`flex items-center justify-between py-1`}>
            <span className={themeClasses.textMuted}>Data Storage:</span>
            <span className={`font-medium ${themeClasses.textPrimary}`}>Local Storage (100% Private)</span>
          </div>
        </div>
      </div>

      {/* 6. DANGER / RESET ZONE */}
      <div className={`rounded-2xl border ${themeClasses.cardBorder} ${themeClasses.cardBg} p-4 shadow-xs transition-colors`}>
        <h4 className={`text-xs font-bold ${themeClasses.textPrimary} mb-1`}>Reset All Application Data</h4>
        <p className={`text-[11px] ${themeClasses.textMuted} mb-3`}>
          Clear all saved trade calculations and reset the form inputs back to defaults.
        </p>
        <button
          onClick={onResetAll}
          className="flex items-center gap-1.5 rounded-xl border border-rose-500/30 bg-rose-500/10 px-3.5 py-2 text-xs font-bold text-rose-500 hover:bg-rose-500/20 active:scale-95 transition cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Reset Everything
        </button>
      </div>
    </div>
  );
};
