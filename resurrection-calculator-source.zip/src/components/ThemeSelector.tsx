import React from 'react';
import { Sun, Moon, Palette, Check } from 'lucide-react';
import { useTheme, ThemeStyle } from '../context/ThemeContext';

interface ThemeSelectorProps {
  variant?: 'inline' | 'modal' | 'card';
}

export const ThemeSelector: React.FC<ThemeSelectorProps> = ({ variant = 'inline' }) => {
  const { style, mode, platform, setStyle, setMode, themeClasses } = useTheme();

  const styles: { id: ThemeStyle; name: string; desc: string; icon: string; badge?: string }[] = [
    {
      id: 'material',
      name: 'Material You (Android)',
      desc: 'Google Material 3 design with dynamic tonal palette and rounded pill elements',
      icon: '🤖',
      badge: platform === 'android' ? 'Nativo Android' : 'Material 3',
    },
    {
      id: 'swiss',
      name: 'Fluent & Swiss Fintech',
      desc: 'Clean & minimalist with modern emerald accents (Windows 11 default)',
      icon: '🪟',
      badge: platform === 'windows' ? 'Nativo Windows' : 'Desktop',
    },
    {
      id: 'terminal',
      name: 'Terminal Pro',
      desc: 'High-contrast trading terminal with monospace metrics',
      icon: '📟',
    },
    {
      id: 'cyber',
      name: 'Cyberpunk HUD',
      desc: 'Midnight cockpit with electric cyan & neon highlights',
      icon: '⚡',
    },
  ];

  if (variant === 'card') {
    return (
      <div className={`rounded-2xl border ${themeClasses.cardBorder} ${themeClasses.cardBg} p-4 sm:p-5 shadow-xs transition-colors`}>
        <div className={`flex items-center justify-between pb-3 border-b ${themeClasses.divider} mb-3.5`}>
          <div className="flex items-center gap-2">
            <Palette className={`h-4 w-4 ${themeClasses.accentText}`} />
            <h3 className={`text-sm font-bold ${themeClasses.textPrimary}`}>Appearance & Theme</h3>
          </div>
          <span className={`text-[11px] font-medium ${themeClasses.textMuted}`}>
            Customize visual style
          </span>
        </div>

        {/* Light / Dark Mode Toggle */}
        <div className="space-y-3">
          <label className={`text-xs font-semibold ${themeClasses.textSecondary} block`}>
            Display Mode (Light / Dark)
          </label>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setMode('light')}
              className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-xs font-bold transition-all ${
                mode === 'light'
                  ? `${themeClasses.accentBg} shadow-sm`
                  : `${themeClasses.cardBorder} ${themeClasses.textSecondary} hover:bg-slate-100/50 dark:hover:bg-slate-800/50`
              }`}
            >
              <Sun className="w-4 h-4" />
              <span>Light Theme</span>
              {mode === 'light' && <Check className="w-3.5 h-3.5 ml-1" />}
            </button>
            <button
              type="button"
              onClick={() => setMode('dark')}
              className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-xs font-bold transition-all ${
                mode === 'dark'
                  ? `${themeClasses.accentBg} shadow-sm`
                  : `${themeClasses.cardBorder} ${themeClasses.textSecondary} hover:bg-slate-100/50 dark:hover:bg-slate-800/50`
              }`}
            >
              <Moon className="w-4 h-4" />
              <span>Dark Theme</span>
              {mode === 'dark' && <Check className="w-3.5 h-3.5 ml-1" />}
            </button>
          </div>

          {/* Design Archetype Selector */}
          <div className="pt-2">
            <label className={`text-xs font-semibold ${themeClasses.textSecondary} block mb-2`}>
              Design Palette & Aesthetics
            </label>
            <div className="space-y-2">
              {styles.map((item) => {
                const isActive = style === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setStyle(item.id)}
                    className={`w-full flex items-center justify-between p-3 rounded-2xl border text-left transition-all ${
                      isActive
                        ? `${themeClasses.accentBorder} ${themeClasses.tagBg} shadow-xs ring-1 ring-current`
                        : `${themeClasses.cardBorder} hover:bg-slate-100/40 dark:hover:bg-slate-800/40`
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span className="text-xl shrink-0">{item.icon}</span>
                      <div className="truncate">
                        <div className={`text-xs font-bold ${themeClasses.textPrimary} flex items-center gap-1.5`}>
                          <span>{item.name}</span>
                          {item.badge && (
                            <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                              {item.badge}
                            </span>
                          )}
                        </div>
                        <div className={`text-[10px] ${themeClasses.textMuted} truncate`}>
                          {item.desc}
                        </div>
                      </div>
                    </div>
                    {isActive && (
                      <span className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full ${themeClasses.accentBg} text-[10px]`}>
                        ✓
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Header quick inline switcher
  return (
    <div className="flex items-center gap-1.5">
      <div className={`flex rounded-xl p-0.5 border ${themeClasses.cardBorder} ${themeClasses.cardBg}`}>
        {styles.map((s) => (
          <button
            key={s.id}
            type="button"
            title={s.name}
            onClick={() => setStyle(s.id)}
            className={`px-2 py-1 text-[11px] font-bold rounded-lg transition-all ${
              style === s.id
                ? `${themeClasses.accentBg} shadow-xs`
                : `${themeClasses.textMuted} hover:${themeClasses.textPrimary}`
            }`}
          >
            {s.name.split(' ')[0]}
          </button>
        ))}
      </div>
      <button
        type="button"
        title={mode === 'light' ? 'Switch to Dark Mode' : 'Switch to Light Mode'}
        onClick={() => setMode(mode === 'light' ? 'dark' : 'light')}
        className={`flex h-8 w-8 items-center justify-center rounded-xl border ${themeClasses.cardBorder} ${themeClasses.cardBg} ${themeClasses.textSecondary} hover:${themeClasses.textPrimary} transition`}
      >
        {mode === 'light' ? <Moon className="w-3.5 h-3.5" /> : <Sun className="w-3.5 h-3.5 text-amber-400" />}
      </button>
    </div>
  );
};
