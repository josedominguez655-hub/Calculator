import React from 'react';
import { History, Trash2, ArrowUpRight, Clock, FileDown } from 'lucide-react';
import { SavedCalculation } from '../types';
import { formatCurrency, formatPercent } from '../utils/calculator';
import { useTheme } from '../context/ThemeContext';

interface HistoryViewProps {
  history: SavedCalculation[];
  onLoad: (calc: SavedCalculation) => void;
  onDelete: (id: string) => void;
  onClear: () => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  history,
  onLoad,
  onDelete,
  onClear,
}) => {
  const { themeClasses } = useTheme();

  const exportCSV = () => {
    if (history.length === 0) return;
    const headers = ['Date', 'Symbol', 'Shares 1', 'Original Price', 'Loss %', 'Target Loss %', 'Shares to Buy', 'New Avg Price', 'Total Cost'];
    const rows = history.map(item => [
      new Date(item.timestamp).toLocaleString(),
      item.symbol || 'N/A',
      item.input.shares1,
      item.input.originalPrice,
      item.result.lossPercent,
      item.result.targetLossPercent,
      item.result.roundedShares,
      item.result.newAvgPrice,
      item.result.totalCost,
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `resurrection_calculator_history_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (history.length === 0) {
    return (
      <div className={`rounded-2xl border border-dashed ${themeClasses.cardBorder} ${themeClasses.cardBg} p-8 text-center transition-colors`}>
        <div className={`mx-auto flex h-12 w-12 items-center justify-center rounded-2xl ${themeClasses.tagBg} ${themeClasses.textMuted} mb-3`}>
          <History className="h-6 w-6" />
        </div>
        <h3 className={`text-sm font-bold ${themeClasses.textPrimary}`}>No Saved Calculations</h3>
        <p className={`mt-1 text-xs ${themeClasses.textMuted} max-w-xs mx-auto`}>
          Whenever you calculate a trade recovery scenario, tap the "Save" button to keep it here for quick reference during market hours.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between px-1">
        <div className="flex items-center gap-2">
          <h2 className={`text-sm font-bold ${themeClasses.textPrimary}`}>Trade History</h2>
          <span className={`rounded-full ${themeClasses.badgeGreen} px-2 py-0.5 text-[10px] font-bold`}>
            {history.length}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={exportCSV}
            className={`flex items-center gap-1 text-[11px] font-semibold ${themeClasses.accentText} hover:opacity-80 transition`}
          >
            <FileDown className="w-3.5 h-3.5" />
            CSV
          </button>
          <button
            onClick={onClear}
            className="flex items-center gap-1 text-[11px] font-semibold text-rose-500 hover:text-rose-600 transition"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Clear
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {history.map((item) => (
          <div
            key={item.id}
            className={`group rounded-2xl border ${themeClasses.cardBorder} ${themeClasses.cardBg} p-3.5 shadow-2xs ${themeClasses.cardHover} transition`}
          >
            <div className={`flex items-start justify-between gap-2 mb-2 pb-2 border-b ${themeClasses.divider}`}>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className={`font-extrabold ${themeClasses.textPrimary} text-xs tracking-wider ${themeClasses.tagBg} px-2 py-0.5 rounded-md`}>
                    {item.symbol || 'STOCK'}
                  </span>
                  {(item.companyName || item.input?.companyName) && (
                    <span className="text-[11px] font-bold text-emerald-500 truncate max-w-[150px]">
                      {item.companyName || item.input?.companyName}
                    </span>
                  )}
                  <span className={`text-[11px] ${themeClasses.textMuted}`}>
                    {item.input.shares1} shs @ ${item.input.originalPrice.toFixed(2)}
                  </span>
                </div>
                <p className={`text-[10px] ${themeClasses.textMuted} flex items-center gap-1 mt-1`}>
                  <Clock className="w-3 h-3" />
                  {new Date(item.timestamp).toLocaleDateString()} {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => onLoad(item)}
                  className={`flex items-center gap-1 rounded-lg ${themeClasses.badgeGreen} px-2.5 py-1 text-[11px] font-bold hover:opacity-80 transition active:scale-95`}
                  title="Load into Calculator"
                >
                  Load
                  <ArrowUpRight className="w-3 h-3" />
                </button>
                <button
                  onClick={() => onDelete(item.id)}
                  className={`rounded-lg p-1 ${themeClasses.textMuted} hover:text-rose-500 transition`}
                  title="Delete from history"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2 text-center text-xs">
              <div className={`rounded-xl ${themeClasses.tagBg} p-2 border ${themeClasses.cardBorder}`}>
                <p className={`text-[10px] ${themeClasses.textMuted} font-medium`}>Loss → Target</p>
                <p className={`font-bold ${themeClasses.textPrimary} text-xs`}>
                  {formatPercent(item.result.lossPercent, 1)} → {formatPercent(item.result.targetLossPercent, 1)}
                </p>
              </div>
              <div className={`rounded-xl p-2 border ${themeClasses.badgeGreen}`}>
                <p className="text-[10px] font-medium opacity-80">Buy Shares</p>
                <p className="font-extrabold text-xs">
                  +{item.result.roundedShares}
                </p>
              </div>
              <div className={`rounded-xl p-2 border ${themeClasses.badgeBlue}`}>
                <p className="text-[10px] font-medium opacity-80">New Avg</p>
                <p className="font-bold text-xs">
                  ${item.result.newAvgPrice.toFixed(2)}
                </p>
              </div>
            </div>

            <div className={`mt-2 text-[11px] ${themeClasses.textMuted} flex items-center justify-between pt-1 text-right`}>
              <span>Total Investment:</span>
              <span className={`font-bold ${themeClasses.textPrimary}`}>{formatCurrency(item.result.totalCost)}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
