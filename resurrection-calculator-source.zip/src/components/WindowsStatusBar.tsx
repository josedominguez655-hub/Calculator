import React, { useState, useEffect } from 'react';
import { Wifi, WifiOff, Keyboard, Laptop } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface WindowsStatusBarProps {
  statusMessage?: string;
  symbol?: string;
  companyName?: string;
  onOpenShortcuts: () => void;
}

export const WindowsStatusBar: React.FC<WindowsStatusBarProps> = ({
  statusMessage = 'Listo',
  symbol,
  companyName,
  onOpenShortcuts,
}) => {
  const { mode } = useTheme();
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return (
    <footer
      id="windows-status-bar"
      className={`h-7 select-none border-t ${
        mode === 'dark' ? 'border-slate-800/80 bg-slate-950/90 text-slate-400' : 'border-slate-200/80 bg-slate-100/90 text-slate-600'
      } backdrop-blur-md px-3 text-[11px] flex items-center justify-between z-40 fixed bottom-0 left-0 right-0 transition-colors`}
    >
      {/* Left: Current calculation / action status */}
      <div className="flex items-center gap-2 min-w-0">
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
        <span className="truncate font-medium">{statusMessage}</span>
      </div>

      {/* Middle: Active ticker / stock info */}
      {symbol && (
        <div className="hidden sm:flex items-center gap-1.5 truncate max-w-[280px]">
          <span className="font-black text-emerald-500">{symbol}</span>
          {companyName && <span className="truncate opacity-75">• {companyName}</span>}
        </div>
      )}

      {/* Right: Connectivity & Windows indicators */}
      <div className="flex items-center gap-3 shrink-0">
        {/* Keyboard Shortcuts Pill */}
        <button
          type="button"
          onClick={onOpenShortcuts}
          title="Ver atajos de teclado"
          className="hidden md:flex items-center gap-1 hover:text-emerald-500 transition-colors cursor-pointer"
        >
          <Keyboard className="w-3 h-3" />
          <span>Atajos (Ctrl+K)</span>
        </button>

        {/* Online / Offline badge */}
        <div className="flex items-center gap-1">
          {isOnline ? (
            <>
              <Wifi className="w-3 h-3 text-emerald-500" />
              <span className="hidden sm:inline">En línea</span>
            </>
          ) : (
            <>
              <WifiOff className="w-3 h-3 text-amber-500" />
              <span className="text-amber-500 font-bold">Sin conexión</span>
            </>
          )}
        </div>

        {/* Windows 11 Indicator */}
        <div className="hidden lg:flex items-center gap-1 opacity-70">
          <Laptop className="w-3 h-3 text-sky-500" />
          <span>Windows 11</span>
        </div>
      </div>
    </footer>
  );
};
