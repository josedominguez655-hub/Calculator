import React, { useState, useEffect } from 'react';
import { Minus, Square, Copy, X, TrendingUp, Sun, Moon, Laptop, Keyboard, Smartphone, Download } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface WindowsTitleBarProps {
  symbol?: string;
  companyName?: string;
  onOpenShortcuts: () => void;
  onOpenInstallModal: () => void;
}

export const WindowsTitleBar: React.FC<WindowsTitleBarProps> = ({
  symbol,
  companyName,
  onOpenShortcuts,
  onOpenInstallModal,
}) => {
  const { mode, toggleMode, themeClasses, style, platform } = useTheme();
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  const handleToggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen?.().catch(() => {});
    } else {
      document.exitFullscreen?.().catch(() => {});
    }
  };

  const handleMinimize = () => {
    window.blur?.();
  };

  const handleClose = () => {
    if (window.confirm('¿Deseas salir de Resurrection Calculator?')) {
      window.close?.();
    }
  };

  const isMaterial = style === 'material';

  return (
    <div
      id="windows-title-bar"
      className={`h-9 select-none flex items-center justify-between border-b ${
        isMaterial
          ? mode === 'dark'
            ? 'border-[#49454f]/40 bg-[#1d1b20]'
            : 'border-[#cac4d0]/60 bg-[#f7f2fa]'
          : mode === 'dark'
          ? 'border-slate-800/80 bg-slate-950/80'
          : 'border-slate-200/80 bg-slate-100/90'
      } backdrop-blur-md px-3 text-xs z-50 sticky top-0 transition-colors`}
    >
      {/* Left: App Icon & Title */}
      <div className="flex items-center gap-2 min-w-0">
        <div
          className={`flex items-center justify-center w-5 h-5 rounded ${
            isMaterial ? 'bg-[#6750a4] text-white' : 'bg-emerald-600 text-white'
          } shadow-2xs shrink-0`}
        >
          <TrendingUp className="w-3.5 h-3.5 stroke-[2.5]" />
        </div>
        <span className={`font-semibold tracking-tight ${themeClasses.textPrimary} truncate hidden sm:inline`}>
          Resurrection Calculator
        </span>
        <span className={`font-semibold tracking-tight ${themeClasses.textPrimary} sm:hidden`}>
          Resurrection
        </span>

        {/* Platform Badge */}
        {isMaterial ? (
          <span className="text-[10px] font-semibold text-purple-700 dark:text-purple-300 bg-purple-500/15 dark:bg-purple-400/15 px-1.5 py-0.2 rounded-full border border-purple-500/20 inline-flex items-center gap-1">
            <Smartphone className="w-2.5 h-2.5" /> Material M3
          </span>
        ) : (
          <span className="text-[10px] font-semibold text-sky-600 dark:text-sky-400 bg-sky-500/10 dark:bg-sky-400/10 px-1.5 py-0.2 rounded border border-sky-500/20 hidden md:inline-flex items-center gap-1">
            <Laptop className="w-2.5 h-2.5" /> Win 11
          </span>
        )}

        {/* Active stock badge if loaded */}
        {symbol && (
          <div
            className={`hidden lg:flex items-center gap-1 text-[11px] font-medium ${
              isMaterial ? 'text-purple-600 dark:text-purple-300 bg-purple-500/10 border-purple-500/20' : 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20'
            } px-2 py-0.5 rounded border truncate max-w-[200px]`}
          >
            <span className="font-black">{symbol}</span>
            {companyName && <span className="text-slate-400 truncate">• {companyName}</span>}
          </div>
        )}
      </div>

      {/* Middle: Subtle Drag / Centered Indicator */}
      <div className="hidden sm:block text-[11px] font-medium text-slate-400 dark:text-slate-500 truncate max-w-[200px]">
        {symbol ? `${symbol} - Posición` : isMaterial ? 'Android Edition' : 'Trade Position Recovery'}
      </div>

      {/* Right: Actions & Controls */}
      <div className="flex items-center h-full">
        {/* Keyboard Shortcuts button */}
        <button
          type="button"
          onClick={onOpenShortcuts}
          title="Atajos de teclado (Ctrl+K)"
          className={`h-7 px-2 flex items-center gap-1 text-[11px] font-medium rounded ${themeClasses.textSecondary} hover:${themeClasses.textPrimary} hover:bg-black/5 dark:hover:bg-white/5 transition-colors mr-1 hidden sm:flex`}
        >
          <Keyboard className="w-3.5 h-3.5" />
          <span className="hidden md:inline">Atajos</span>
        </button>

        {/* Download & Modify button */}
        <button
          type="button"
          onClick={onOpenInstallModal}
          title="Descargar aplicación o ver opciones para modificarla"
          className={`h-7 px-2.5 flex items-center gap-1.5 text-[11px] font-bold rounded cursor-pointer ${
            isMaterial
              ? 'text-purple-900 dark:text-purple-100 bg-purple-500/20 hover:bg-purple-500/30'
              : 'text-emerald-700 dark:text-emerald-300 bg-emerald-500/15 hover:bg-emerald-500/25'
          } transition-colors mr-1.5`}
        >
          <Download className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Descargar / Modificar</span>
          <span className="sm:hidden">Descargar</span>
        </button>

        {/* Dark / Light Toggle */}
        <button
          type="button"
          onClick={toggleMode}
          title={mode === 'light' ? 'Modo Oscuro (Ctrl+D)' : 'Modo Claro (Ctrl+D)'}
          className={`h-7 w-7 flex items-center justify-center rounded ${themeClasses.textSecondary} hover:${themeClasses.textPrimary} hover:bg-black/5 dark:hover:bg-white/5 transition-colors mr-1`}
        >
          {mode === 'light' ? <Moon className="w-3.5 h-3.5" /> : <Sun className="w-3.5 h-3.5 text-amber-400" />}
        </button>

        {/* Windows 11 Native Control Buttons (Always on desktop/windows, subtle on mobile) */}
        <div className="flex items-center h-full ml-1">
          {/* Minimize */}
          <button
            type="button"
            onClick={handleMinimize}
            title="Minimizar"
            className="h-full w-10 flex items-center justify-center text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-200/80 dark:hover:bg-slate-800 transition-colors"
          >
            <Minus className="w-3.5 h-3.5" />
          </button>

          {/* Maximize / Fullscreen / Ocultar navegador */}
          <button
            type="button"
            onClick={handleToggleFullscreen}
            title={isFullscreen ? 'Restaurar pantalla normal' : 'Modo Pantalla Completa (Ocultar navegador)'}
            className={`h-full px-2.5 flex items-center justify-center text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-200/80 dark:hover:bg-slate-800 transition-colors ${
              isFullscreen ? 'text-emerald-500 font-bold' : ''
            }`}
          >
            {isFullscreen ? <Copy className="w-3.5 h-3.5 text-emerald-500" /> : <Square className="w-3.5 h-3.5" />}
          </button>

          {/* Close */}
          <button
            type="button"
            onClick={handleClose}
            title="Cerrar ventana"
            className="h-full w-10 flex items-center justify-center text-slate-500 hover:text-white hover:bg-rose-600 transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
